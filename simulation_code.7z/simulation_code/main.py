from Gillespie.run_grid import play_sim, run_simulations

# play_sim()
run_simulations(n=15)
