from trajectory_inheritance.get import get
from Directories import home
import pandas as pd
import json
from tqdm import tqdm
import numpy as np
from copy import copy
from scipy.signal import medfilt
from scipy.ndimage import gaussian_filter
from matplotlib import pyplot as plt
from os import path
import os

average_radius_HIT = {'I': {'M': 0.5823, 'L': 1.1646, 'SL': 1.7469000000000001, 'XL': 2.3292},
                      'T': {'M': 0.738675, 'L': 1.47735, 'SL': 2.216025, 'XL': 2.9547},
                      'H': {'M': 0.748475, 'L': 1.49695, 'SL': 2.245425, 'XL': 2.9939}}

periodicity = {'H': 2, 'I': 2, 'RASH': 2, 'LASH': 2, 'SPT': 1, 'T': 1}
average_radius = {'ant': {'S': 0.921492, 'S (> 1)': 0.921492, 'Single (1)': 0.921492, 'M': 1.842981,
                          'L': 3.662930, 'XL': 7.295145},
                  'human': {'Small Far': 1.1979396, 'Small Near': 1.1979396, 'Small': 1.1979396,
                            'Medium': 2.441953, 'Large': 4.8992658},
                  'gillespie': {'S': 0.921492, 'S (> 1)': 0.921492, 'Single (1)': 0.921492, 'M': 1.842981,
                                'L': 3.662930, 'XL': 7.295145}}
with open(path.join(home, 'Setup', 'ResizeFactors.json'), "r") as read_content:
    ResizeFactors = json.load(read_content)


def average_radii_HIT(size, shape):
    return {'H': 2.9939 * ResizeFactors['ant'][size],
            'I': 2.3292 * ResizeFactors['ant'][size],
            'LongI': 5 * ResizeFactors['ant'][size],
            'T': 2.9547 * ResizeFactors['ant'][size],
            'LongT': 2.26,
            'SPT': 7.295145 * ResizeFactors['ant'][size],
            }[shape]


class PathLength:
    """
    This class is similar to the one in Analysis/Efficiency/PathLength.py. But shorter and self-contained.
    """
    def __init__(self, x):
        self.x = copy(x)

    def translational_distance(self, kernel_size=None, smooth=True, check_smoothing=False) -> float:
        position = self.x.position
        # assert position.size > 5, 'Trajectory is too short to calculate translational distance'

        position_filtered = deepcopy(position)
        if smooth:
            if check_smoothing:
                names = self.x.filename + '_x', self.x.filename + '_y'
            else:
                names = None, None
            position_filtered[:, 0] = self.smooth_array(position[:, 0], int(self.x.fps/4), kernel_size=kernel_size,
                                                        name=names[0])
            position_filtered[:, 1] = self.smooth_array(position[:, 1], int(self.x.fps/4), kernel_size=kernel_size,
                                                        name=names[1])
        d = np.abs(np.linalg.norm(np.diff(position_filtered, axis=0), axis=1)).sum()
        return d

    def rotational_distance(self, kernel_size=None, smooth=True, check_smooth=False) -> float:
        angle = self.x.angle
        # assert angle.size > 5, 'Trajectory is too short to calculate rotational distance'
        assert not np.isnan(angle).any(), \
            'Angle array contains NaNs, use unwrapped_angle = self.ConnectAngle(angle, self.x.shape)'

        p = periodicity[self.x.shape]
        unwrapped_angle = 1 / p * np.unwrap(p * angle)

        new_unwrapped_angle = unwrapped_angle
        if smooth:
            if check_smooth:
                name = self.x.filename + '_angle'
            else:
                name = None
            new_unwrapped_angle = self.smooth_array(unwrapped_angle, self.x.fps, kernel_size=kernel_size,
                                                    name=name)

        d = np.abs(np.diff(new_unwrapped_angle)).sum()  # this is NOT multiplied with average radius, yet!!
        return d

    def pL(self, HIT=False) -> float:
        x = self.x.position[:, 0]
        y = self.x.position[:, 1]

        if not HIT:
            theta = np.unwrap(self.x.angle % (2 * np.pi)) * average_radius[self.x.solver][self.x.size]
        else:
            aR_HIT = average_radii_HIT(self.x.size, self.x.shape)
            theta = np.unwrap(self.x.angle % (2 * np.pi)) * aR_HIT

        coords = np.stack((x, y, theta), axis=1)
        d = np.abs(np.linalg.norm(np.diff(coords, axis=0), axis=1)).sum()

        return d

    @staticmethod
    def smooth_array(array, fps, kernel_size=None, name=None):
        if kernel_size is None:
            kernel_size = 8 * (fps // 4) + 1
        new_array = medfilt(array, kernel_size=kernel_size)
        new_array1 = gaussian_filter(new_array, sigma=kernel_size // 5)
        if name is not None:
            plt.figure()
            plt.plot(array)
            plt.plot(new_array)
            plt.plot(new_array1)
            plt.savefig('smooth_check\\' + name + '.png', dpi=300)
            plt.close()

        return new_array1


def save_pL_trans_rot(df, solver_string, ts=None, HIT=False):
    trans, rot, winner = {}, {}, {}
    pL = {}
    for filename in tqdm(df['filename'], desc=solver_string):
        traj = get(filename)
        if traj.solver == 'human':
            traj.smooth(2)
        else:
            traj.smooth(0.25)
        p_l = PathLength(traj)
        trans[filename] = p_l.translational_distance(smooth=False)
        rot[filename] = p_l.rotational_distance(smooth=False)
        pL[filename] = p_l.pL(HIT=HIT)
        if ts is not None and 'winner' not in df.columns:
            winner[filename] = ts[filename][-1] == 'h'

        print(filename, rot[filename], trans[filename])

    results_folder = home + '\\Analysis\\Efficiency\\results_double_check\\'
    with open(results_folder + solver_string + '_trans_0.25.json', 'w') as f:
        json.dump(trans, f)
    with open(results_folder + solver_string + '_rot_0.25.json', 'w') as f:
        json.dump(rot, f)
    with open(results_folder + solver_string + '_pL_0.25.json', 'w') as f:
        json.dump(pL, f)
    if ts is not None and 'winner' not in df.columns:
        with open(results_folder + solver_string + '_winner.json', 'w') as f:
            json.dump(winner, f)


def gillespie_save_trans_rot():
    # date = '2023_12_19'
    # date = '2023_06_27'
    # date = '2023_12_31_free'
    # date = '2024_01_08_XS'

    date_no_skirt = '2024_01_29_no_skirt'
    date_with_skirt = '2024_02_21_with_skirt'  # 2024_02_15_with_skirt

    for date in [date_with_skirt, date_no_skirt]:
        df_gillespie = pd.read_excel(home + '\\Gillespie\\' + date + '_sim.xlsx')
        solver_string = 'gillespie_' + date

        with open(home + '\\ConfigSpace\\time_series_gillespie_' + date + '.json', 'r') as json_file:
            ts = json.load(json_file)
            json_file.close()
        save_pL_trans_rot(df_gillespie, solver_string, ts=ts)


def ants_save_trans_rot():
    solver_string = 'ant'
    df_ants = pd.read_excel(home + '\\DataFrame\\final\\df_ant_excluded.xlsx')
    save_pL_trans_rot(df_ants, solver_string)


def ants_HIT_save_trans_rot():
    solver_string = 'ant_HIT'

    directory = home + '\\DataFrame\\final\\df_ant_HIT.xlsx'
    # data_home = path.join(path.sep + path.sep + 'phys-guru-cs', 'ants', 'Tabea', 'PyCharm_Data', 'AntsShapes')
    # df_dir = path.join(data_home, 'DataFrame', 'data_frame.xlsx')
    # df_ant = pd.read_excel(df_dir)
    #
    # df_ant_HIT = df_ant.loc[df_ant['shape'].isin(['H', 'I', 'T'])].copy()
    # save in directory
    # df_ant_HIT.to_excel(directory)

    df_ants = pd.read_excel(directory)
    # exclude all where free is 1
    df_ants = df_ants.loc[df_ants['free'] == 0]

    save_pL_trans_rot(df_ants, solver_string, HIT=True)


def humans_save_trans_rot():
    solver_string = 'human'
    df_human = pd.read_excel(home + '\\DataFrame\\final\\df_human.xlsx')
    save_pL_trans_rot(df_human, solver_string)


def number_of_parts_and_exp():
    directory = home + '\\DataFrame\\final\\df_ant_HIT.xlsx'
    df_ants_HIT = pd.read_excel(directory)

    solver = 'ant'
    sizes = ['XS', 'S', 'M', 'L', 'SL', 'XL']
    total = 0
    for shape in ['I', 'T', 'H']:
        for size in sizes:
            # find the number of experiments for each shape
            num_exp = len(df_ants_HIT[(df_ants_HIT['shape'] == shape) & (df_ants_HIT['size'] == size)])
            total += num_exp
            print(solver, shape, size, 'exp num', num_exp)
    print('total', total)
    print(len(df_ants_HIT))


if __name__ == '__main__':
    # number_of_parts_and_exp()
    # humans_save_trans_rot()
    # ants_save_trans_rot()
    # gillespie_save_trans_rot()
    # ants_HIT_save_trans_rot()
    pass


