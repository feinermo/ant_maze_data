import numpy as np
import pandas as pd
import scipy.optimize as opt
from os import path
from matplotlib import pyplot as plt


def exp_correlation(x, b, c):
    return (1 - c) * np.exp(-x * 1 / b) + c


def plot_corr(corr_distances, corr, popt):
    plt.plot(corr_distances, corr, 'o')
    plt.plot(corr_distances, exp_correlation(corr_distances, *popt), label='fit')
    plt.savefig('corr.png')
    # print location of saved file
    print(path.abspath('corr.png'))
    plt.close()


# Auto-correlation
def autocorrelation(xs, time_step):
    cors = []
    for x in xs:
        n = len(x)
        mean = np.mean(x)
        var = np.var(x)

        cors.append(np.array([np.correlate(x[:n-lag] - mean, x[lag:] - mean, mode='valid')[0] / (var * (n - lag))
                         for lag in range(n)]))
    lengths = [len(cor) for cor in cors]
    min_length = min(lengths)
    cors = np.array([cor[:min_length] for cor in cors])
    mean_cor = np.nanmean(cors, axis=0)
    corr_distances = np.arange(len(mean_cor)) * time_step

    # cut off after corr_distances > 5
    mean_cor = mean_cor[corr_distances < 5]
    corr_distances = corr_distances[corr_distances < 5]

    try:
        popt, errors = opt.curve_fit(exp_correlation, corr_distances, mean_cor)
        sigma = np.sqrt(np.diag(errors))
        plot_corr(corr_distances, mean_cor, popt)
    except ValueError as e:
        print(e)
        popt = [0, 0]
        sigma = [0, 0]

    return pd.Series([*popt, *sigma], ['corr_time', 'constant', 'sigma_corr_time', 'sigma_constant', ])


def correlation(var_trails, fps, max_correlation_distance=10, data_points: int=100, corr_function=exp_correlation) -> pd.Series:
    """
    :param corr_function: callable describing the fit of the correlation function
    :param data_points: Number of data points to sample when calculating correlation
    :param max_correlation_distance: maximum distance to check correlation
    :param name: name of the trail
    :param var_trails: variables taken from trails
    :return: optimal fit parameters in pd.Series
    """

    # inspected correlation_distances
    corr_distances = np.linspace(0, max_correlation_distance, data_points)

    var_trail_corr = []
    for counter, var_trail in enumerate(var_trails):
        var_trail_corr.append([1])
        for t in corr_distances[1:]:
            index = int(np.floor(t * fps))
            if len(var_trail) > index * 1.1:
                array1 = var_trail[:-index:index]
                array2 = var_trail[index::index]
                correlation = np.mean(array1 * array2)
            else:
                correlation = np.NaN
            var_trail_corr[-1].append(correlation)

    corr = np.nanmean(np.array(var_trail_corr), axis=0)
    # reduce to average of values for eveyr time_step
    # corr = np.array([np.mean(corr[i:i+int(fps)]) for i in range(0, len(corr), int(fps))])
    #
    # plt.plot(corr_distances, corr)
    # plt.show()
    try:
        popt, errors = opt.curve_fit(corr_function, corr_distances[:data_points], corr[:data_points])
        sigma = np.sqrt(np.diag(errors))
        plot_corr(corr_distances, corr, popt)
    except ValueError as e:
        print(e)
        popt = [0, 0]
        sigma = [0, 0]

    return pd.Series([*popt, *sigma], ['constant', 'corr_time', 'sigma_constant', 'sigma_corr_time'])