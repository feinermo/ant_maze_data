
from __future__ import print_function
import numpy as np
import time
import cv2
from os import path
import sys
import imutils
from tqdm import tqdm
from matplotlib import pyplot as plt
import pandas as pd
from Directories import home
import numpy as np


def get_frame(c: cv2.VideoCapture, height: int = None, cut_out=None):
    if c.isOpened():
        ret, frame = c.read()
        if cut_out is not None:
            frame = frame[cut_out[0][0]:cut_out[0][1], cut_out[1][0]:cut_out[1][1]]
        if ret is True:
            frame = imutils.resize(frame, height=height)
            return frame
        else:
            return False


def open_video_writer(cap, movie_name, height=800, cut_out=None, fps=50):
    frame_shape = get_frame(cap, height=height, cut_out=cut_out).shape
    (h, w) = tuple(np.array(frame_shape)[:2])
    final_output_shape = (h, int(frame_shape[1]), 3)
    saved_video = path.join(video_directory, sys.argv[0].split('/')[-1].split('.')[0] +
                            movie_name[:-4] + '.mp4v')
    print('Movie saved in ', saved_video)
    video_writer = cv2.VideoWriter(saved_video,
                                   fourcc=cv2.VideoWriter_fourcc(*'DIVX'),
                                   fps=fps,
                                   frameSize=(final_output_shape[1], final_output_shape[0]))
    return video_writer


def find_cut_out(movie_name, frames, video_directory):
        if not path.exists(video_directory):
            raise ValueError(video_directory, '... video directory does not exist')

        address = path.join(video_directory, movie_name)
        cap = cv2.VideoCapture(address)

        for count in tqdm(range(frames[0], frames[1], 1)):
            cap.set(cv2.CAP_PROP_POS_FRAMES, count)
            time.sleep(1 / 50)

            img = get_frame(cap, cut_out=None)
            # open frame
            cv2.imshow('image', img)

            # give me information on my curser location when I click on the image

            def click_event(event, x, y, flags, params):

                # checking for left mouse clicks
                if event == cv2.EVENT_LBUTTONDOWN:
                    # displaying the coordinates
                    # on the Shell
                    print(x, ' ', y)

                    # displaying the coordinates
                    # on the image window
                    font = cv2.FONT_HERSHEY_SIMPLEX
                    cv2.putText(img, str(x) + ',' +
                                str(y), (x, y), font,
                                1, (255, 0, 0), 2)
                    cv2.imshow('image', img)

                    # checking for right mouse clicks
                if event == cv2.EVENT_RBUTTONDOWN:
                    # displaying the coordinates
                    # on the Shell
                    print(x, ' ', y)

                    # displaying the coordinates
                    # on the image window
                    font = cv2.FONT_HERSHEY_SIMPLEX
                    b = img[y, x, 0]
                    g = img[y, x, 1]
                    r = img[y, x, 2]
                    cv2.putText(img, str(b) + ',' +
                                str(g) + ',' + str(r),
                                (x, y), font, 1,
                                (255, 255, 0), 2)
                    cv2.imshow('image', img)

            cv2.setMouseCallback('image', click_event)

            if cv2.waitKey(1) & 0xFF == ord('q') or type(img) is bool:
                break
            img = cv2.cvtColor(np.array(img), cv2.COLOR_BGR2BGRA)
        cap.release()
        cv2.destroyAllWindows()


def speed_up(movie_names, speed_up=1, height=800, video_writer=None, fps=50):
    if type(movie_names) is dict:
        # make list of tuples
        movie_names = [(movie_name, frames, cut_out) for movie_name, (frames, cut_out) in movie_names.items()]

    # print the length of resulting movie
    seconds = sum([frames[1] - frames[0] for _, frames, _ in movie_names]) / fps / speed_up
    min_sec = str(np.floor(seconds / 60).astype(int)) + 'min  + ' + str(seconds % 60).split('.')[0] + 'sec'
    print('Length of resulting movie: ', min_sec)

    for movie_name, frames, cut_out in movie_names:

        if not path.exists(video_directory):
            raise ValueError(video_directory, '... video directory does not exist')

        address = path.join(video_directory, movie_name)
        cap = cv2.VideoCapture(address)

        if video_writer is None:
            video_writer = open_video_writer(cap, movie_name, height=height, cut_out=cut_out, fps=fps)

        for count in tqdm(range(frames[0], frames[1], speed_up)):
            cap.set(cv2.CAP_PROP_POS_FRAMES, count)
            time.sleep(1 / fps)

            img = get_frame(cap, height=height, cut_out=cut_out)
            if cv2.waitKey(1) & 0xFF == ord('q') or type(img) is bool:
                break

            img = cv2.cvtColor(np.array(img), cv2.COLOR_BGR2BGRA)
            # cv2.imshow('frame', img)
            video_writer.write(img)

        cap.release()
        cv2.destroyAllWindows()
    video_writer.release()


if __name__ == '__main__':
    # video_directory = path.join('C:\\', 'Users', 'tabea', 'Desktop')
    # video_directory = '{0}{1}phys-guru-cs{2}ants{3}honeypot{4}honeypot{5}Udi{6}Ants_videos{7}' \
    #                   'Paratrechina longicornis{8}2016{9}2016-09-19 (ILAN (fixed release point test (large)))'. \
    #     format(*[path.sep for _ in range(10)])

    # video_directory = '{0}{1}phys-guru-cs{2}ants{3}Tabea{4}Human Experiments{5}Output{6}Small Near{7}Videos{8}'\
    #     .format(*[path.sep for _ in range(9)])

    # movie_names = {'SSPT_4800001_SSpecialT_1_ants (part 1).avi': [1, 48648],
    #                'SSPT_4800002_SSpecialT_1_ants (part 2).avi': [1, 22682]}

    # movie_names = {'LSPT_4670004_LSpecialT_1_ants (part 1).avi': [1, 49855],
    #                'LSPT_4670005_LSpecialT_1_ants (part 2).avi': [1, 36256]}

    # movie_names = {'S4700010_MSpecialT.MP4': [1045, 49999],
    #                'S4700011_MSpecialT.MP4': [1, 27472]}

    # video_directory = path.join('C:\\', 'Users', 'tabea', 'Documents', 'Weizmann_Research', 'Presentations')
    # movie_names = [['CrazyAnts_Rotating Planet.mp4', [7891, 8122]],
    #                ['CrazyAnts_Rotating Planet.mp4', [8747, 9342]]]

    # """
    # For the paper: EXPERIMENTS WITH ANTS
    # """
    #

    # Supplementary Movie 1: Single ant
    # P:\Tabea\Videos\24_08_2021_(CactusGarden)\S4780007_SSpecialT.MP4
    #
    # Supplementary Movie 2: Small group of ants
    # P:\Tabea\Videos\08_09_2022_(Cactus Garden Wall)\S5190014_SSpecialT.MP4
    #
    # Supplementary Movie 3: Large group of ants
    # P:\Tabea\Videos\01_08_2021_(Mexico Building)\S4630010_XLSpecialT.MP4
    #
    # Supplementary Movie 4: Single person
    # raw data:
    # P:\Tabea\Human Experiments\Raw Data and Videos\2022-03-08\Videos\Small near maze\NVR_ch3_main_20220308120914_20220308121224.asf
    # tracked:
    # P:\Tabea\Human Experiments\Output\Small Near\Videos\small_20220308120914_20220308121224_Full.avi
    #
    # Supplementary Movie 5: Large group of people
    # raw data
    # P:\Tabea\Human Experiments\Raw Data and Videos\2022-06-06\Videos\Large maze\NVR_ch1_main_20220606172145_20220606172851.asf
    # tracked:
    # P:\Tabea\Human Experiments\Output\Large\Videos\large_20220606172145_20220606172851_Corrected.avi



    # df_ant_excluded = pd.read_excel(home + '\\DataFrame\\final\\df_ant_excluded.xlsx')
    # df_small_winner = df_ant_excluded[np.logical_and(df_ant_excluded['winner'], df_ant_excluded['size'] == 'S (> 1)')]['filename']
    # video_directory = '{0}{1}phys-guru-cs{2}ants{3}Tabea{4}Videos{5}08_09_2022_(Cactus Garden Wall){6}' \
    #     .format(*[path.sep for _ in range(7)])
    # # find_cut_out('S5190014_SSpecialT.MP4', [52, 60], video_directory)
    # movie_names = {
    #     'S5190014_SSpecialT.MP4': ([52, 23929], [[363, 740], [630, 1230]])
    # }
    # speed_up(movie_names, speed_up=10, height=800, video_writer=None, fps=50)
    #
    # video_directory = '{0}{1}phys-guru-cs{2}ants{3}Tabea{4}Videos{5}01_08_2021_(Mexico Building){6}' \
    #     .format(*[path.sep for _ in range(7)])
    # # find_cut_out('S4630010_XLSpecialT.MP4', [318, 500], video_directory)
    # movie_names = {
    #     'S4630010_XLSpecialT.MP4': ([318, 15106], [[20, 1035], [300, 1720]]),
    #     # 'S4630011_XLSpecialT.MP4': ([1, 40466],[[20, 1025], [530, 1720]])
    #                }
    # speed_up(movie_names, speed_up=10, height=800, video_writer=None, fps=50)
    #
    # video_directory = '{0}{1}phys-guru-cs{2}ants{3}Tabea{4}Human Experiments{5}Output{6}Small Near{7}Videos{8}'\
    #     .format(*[path.sep for _ in range(9)])
    # # find_cut_out('small_20220308120914_20220308121224_Full.avi', [1, 1160], video_directory)
    # movie_names = {'small_20220308120914_20220308121224_Full.avi': ([1, 3491], [[0, 615], [20, 1030]])}
    # speed_up(movie_names, speed_up=10, height=800, video_writer=None, fps=30)

    video_directory = '{0}{1}phys-guru-cs{2}ants{3}Tabea{4}Human Experiments{5}Output{6}Large{7}Videos{8}'\
        .format(*[path.sep for _ in range(9)])
    # find_cut_out('large_20220606172145_20220606172851_Corrected.avi', [1, 1160], video_directory)
    movie_names = {'large_20220606172145_20220606172851_Corrected.avi': ([1, 7000], [[1, 842], [1, 1200]])}
    speed_up(movie_names, speed_up=10, height=800, video_writer=None, fps=30)

    # """
    # For the paper: SIMULATIONS WITH ANTS
    # """
    # video_directory = '{0}{1}phys-guru-cs{2}ants{3}Tabea{4}movies_for_publication{5}'\
    #     .format(*[path.sep for _ in range(6)])
    # # find_cut_out('AntSolverSim_LargeGroup.mp4', [1, 10], video_directory)
    # movie_names = {'AntSolverSim_LargeGroup.mp4': ([1, 97822], [[1, 672], [1, 1138]])}
    # speed_up(movie_names, speed_up=60, height=800, video_writer=None, fps=30)
    #
    # video_directory = '{0}{1}phys-guru-cs{2}ants{3}Tabea{4}movies_for_publication{5}'\
    #     .format(*[path.sep for _ in range(6)])
    # # find_cut_out('AntSolverSim_LargeGroup.mp4', [1, 10], video_directory)
    # movie_names = {'AntSolverSim_SmallGroup.mp4': ([1, 97822], [[1, 672], [1, 1138]])}
    # speed_up(movie_names, speed_up=60, height=800, video_writer=None, fps=30)
