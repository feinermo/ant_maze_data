import numpy as np

# small group of ants (exp)
# S5190014_SSpecialT
len_original = (23929-52) * 1/50
len_shortened = 47
print('small group of ants (exp), speed up:', len_original / len_shortened)

# large group of ants (exp)
# S4630010_XLSpecialT
len_original = (15106-318) * 1/50
len_shortened = 29
print('large group of ants (exp), speed up:', len_original / len_shortened)


# single person (exp)
# small_20220308120914_20220308121224_Full.avi
len_original = 3461 * 1/30
len_shortened = 11
print('single person, speed up:', len_original / len_shortened)


# large group of people (exp)
# large_20220606172145_20220606172851_Corrected
len_original = 7351 * 1/30
len_shortened = 24
print('large group of people, NC, speed up:', len_original / len_shortened)

# small group of ants (sim)
len_original = 715
len_shortened = 39
print('small group of ants (sim), speed up:', len_original / len_shortened)

# large group of ants (sim)
len_original = 978
len_shortened = 54
print('large group of ants (sim), speed up:', len_original / len_shortened)