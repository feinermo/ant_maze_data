
from __future__ import print_function
import numpy as np
import time
import cv2
from os import path
import sys
import imutils
from tqdm import tqdm
from matplotlib import pyplot as plt
import pandas as pd
from Directories import home
import numpy as np


def get_frame(c: cv2.VideoCapture, height: int = None, cut_out=None):
    if c.isOpened():
        ret, frame = c.read()
        if cut_out is not None:
            frame = frame[cut_out[0][0]:cut_out[0][1], cut_out[1][0]:cut_out[1][1]]
        if ret is True:
            frame = imutils.resize(frame, height=height)
            return frame
        else:
            return False


def open_video_writer(cap, movie_name, height=800, cut_out=None, fps=50):
    frame_shape = get_frame(cap, height=height, cut_out=cut_out).shape
    (h, w) = tuple(np.array(frame_shape)[:2])
    final_output_shape = (h, int(frame_shape[1]), 3)
    saved_video = path.join(video_directory, sys.argv[0].split('/')[-1].split('.')[0] +
                            movie_name[:-4] + '.mp4v')
    print('Movie saved in ', saved_video)
    video_writer = cv2.VideoWriter(saved_video,
                                   fourcc=cv2.VideoWriter_fourcc(*'DIVX'),
                                   fps=fps,
                                   frameSize=(final_output_shape[1], final_output_shape[0]))
    return video_writer


def find_cut_out(movie_name, frames, video_directory):
        if not path.exists(video_directory):
            raise ValueError(video_directory, '... video directory does not exist')

        address = path.join(video_directory, movie_name)
        cap = cv2.VideoCapture(address)

        for count in tqdm(range(frames[0], frames[1], 1)):
            cap.set(cv2.CAP_PROP_POS_FRAMES, count)
            time.sleep(1 / 50)

            img = get_frame(cap, cut_out=None)
            # open frame
            cv2.imshow('image', img)

            # give me information on my curser location when I click on the image

            def click_event(event, x, y, flags, params):

                # checking for left mouse clicks
                if event == cv2.EVENT_LBUTTONDOWN:
                    # displaying the coordinates
                    # on the Shell
                    print(x, ' ', y)

                    # displaying the coordinates
                    # on the image window
                    font = cv2.FONT_HERSHEY_SIMPLEX
                    cv2.putText(img, str(x) + ',' +
                                str(y), (x, y), font,
                                1, (255, 0, 0), 2)
                    cv2.imshow('image', img)

                    # checking for right mouse clicks
                if event == cv2.EVENT_RBUTTONDOWN:
                    # displaying the coordinates
                    # on the Shell
                    print(x, ' ', y)

                    # displaying the coordinates
                    # on the image window
                    font = cv2.FONT_HERSHEY_SIMPLEX
                    b = img[y, x, 0]
                    g = img[y, x, 1]
                    r = img[y, x, 2]
                    cv2.putText(img, str(b) + ',' +
                                str(g) + ',' + str(r),
                                (x, y), font, 1,
                                (255, 255, 0), 2)
                    cv2.imshow('image', img)

            cv2.setMouseCallback('image', click_event)

            if cv2.waitKey(1) & 0xFF == ord('q') or type(img) is bool:
                break
            img = cv2.cvtColor(np.array(img), cv2.COLOR_BGR2BGRA)
        cap.release()
        cv2.destroyAllWindows()


def speed_up(movie_names, speed_up=1, height=800, video_writer=None, fps=50):
    if type(movie_names) is dict:
        # make list of tuples
        movie_names = [(movie_name, frames, cut_out) for movie_name, (frames, cut_out) in movie_names.items()]

    # print the length of resulting movie
    seconds = sum([frames[1] - frames[0] for _, frames, _ in movie_names]) / fps / speed_up
    min_sec = str(np.floor(seconds / 60).astype(int)) + 'min  + ' + str(seconds % 60).split('.')[0] + 'sec'
    print('Length of resulting movie: ', min_sec)

    for movie_name, frames, cut_out in movie_names:

        if not path.exists(video_directory):
            raise ValueError(video_directory, '... video directory does not exist')

        address = path.join(video_directory, movie_name)
        cap = cv2.VideoCapture(address)

        if video_writer is None:
            video_writer = open_video_writer(cap, movie_name, height=height, cut_out=cut_out, fps=fps)

        for count in tqdm(range(frames[0], frames[1], speed_up)):
            cap.set(cv2.CAP_PROP_POS_FRAMES, count)
            time.sleep(1 / fps)

            img = get_frame(cap, height=height, cut_out=cut_out)
            if cv2.waitKey(1) & 0xFF == ord('q') or type(img) is bool:
                break

            img = cv2.cvtColor(np.array(img), cv2.COLOR_BGR2BGRA)
            # cv2.imshow('frame', img)
            video_writer.write(img)

        cap.release()
        cv2.destroyAllWindows()
    video_writer.release()


if __name__ == '__main__':
    # video_directory = '{0}{1}phys-guru-cs{2}ants{3}honeypot{4}honeypot{5}Udi{6}Ants_videos{7}' \
    #                   'Paratrechina longicornis{8}2016{9}2016-09-19 (ILAN (fixed release point test (large)))'. \
    #     format(*[path.sep for _ in range(10)])

    # """
    # For the paper: EXPERIMENTS WITH ANTS
    # """

    # Supplementary Movie 1: Small group, I
    # P:\LAB CENTER\Lab Data\Alumni Members\Aviram\Shapes\2019-09-10 (Line's nest, 3D printed T and I)\S4200003_smallI.MP4

    # Supplementary Movie 2: Large group, I
    # P:\LAB CENTER\Lab Data\Alumni Members\Aviram\Shapes\2019-09-09 (Line's nest, 3D printed I and H)\S4190003_50fpsXLI.MP4
    #
    # Supplementary Movie 1: Small group, H
    # P:\LAB CENTER\Lab Data\Alumni Members\Aviram\Shapes\2019-09-08 (Shed small H and T)\S4140016.MP4
    #
    # Supplementary Movie 2: Large group, H
    # P:\LAB CENTER\Lab Data\Alumni Members\Aviram\Shapes\2019-09-05 (Shed largest H)\S4100023.MP4
    #
    # Supplementary Movie 3: LongT (20x)
    # P:\LAB CENTER\Lab Data\Alumni Members\Aviram\Shapes\2019-09-11 (Shed sHIT & asymmetric H)\S4070010_longT.MP4


    video_directory = '{0}{1}phys-guru-cs{2}ants{3}Tabea{4}Videos{5}08_09_2022_(Cactus Garden Wall){6}' \
        .format(*[path.sep for _ in range(7)])
    # find_cut_out('S5190014_SSpecialT.MP4', [52, 60], video_directory)
    movie_names = {
        'S5190014_SSpecialT.MP4': ([52, 23929], [[363, 740], [630, 1230]])
    }
    speed_up(movie_names, speed_up=10, height=800, video_writer=None, fps=50)
