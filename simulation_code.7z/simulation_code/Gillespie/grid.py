from itertools import product
from tqdm import tqdm
from Gillespie.HIT_stats import HIT_statistics, get_exp_df, color_dict, new_sizing, sim_names, shapes, shapes_sizes, maxx, x_value
from Directories import mini_SaverDirectories, home
from matplotlib import pyplot as plt
import numpy as np
from trajectory_inheritance.trajectory_gillespie import Maze, Trajectory_gillespie
import os
import pandas as pd
import seaborn as sns
import json
from datetime import datetime

size = 'L'
# forceTotal = 0.1 # within 0.4 seconds, its at maximal speed and equilibrizes at around 1.6
# forceTotal = 5 # within 0.4 seconds, its at maximal speed and equilibrizes at around 1.25
time_step = 0.2

gravnon_uniform_force_corner_rnd_corner = [(False, False, False),
                                           (True, False, False),
                                           (False, True, False),
                                           (True, True, False),
                                           (False, True, True),
                                           (True, True, True),
                                           ]

gravnon_uniform_force_corner_rnd_corner = [(False, False, False),
                                           (False, True, False),
                                           (False, True, True),
                                           (True, True, True),
                                           ]

keys = ['_'.join(map(str, item)) for item in gravnon_uniform_force_corner_rnd_corner]

color_dict_HIT = {
    'True L True': "#2ca02c",
    'True L False': "#1f77b4",
    'True M True': "#98df8a",
    'True M False': "#aec7e8",
    'False L False': "#d62728",
    'False M False': "#ff9896"
}

def flatten(t: list):
    if isinstance(t[0], list):
        return [item for sublist in t for item in sublist]
    else:
        return t


class GridIterator:
    def __init__(self, grid: dict, shapes):
        self.grid = grid
        self.shapes = shapes

        self.prob_rnds = np.unique(np.sort([i[0] for i in flatten(list(self.grid.values()))])).tolist()
        self.kappas = np.unique(np.sort([i[1] for i in flatten(list(self.grid.values()))])).tolist()
        self.forceTotal = np.unique(np.sort([i[4] for i in flatten(list(self.grid.values()))])).tolist()

    def __len__(self):
        i = 0
        for _ in self:
            i += 1
        return i

    # def __iter__(self):
    #     for prob_rnd, kappa in product(self.prob_rnds, self.kappas):
    #         for force_corner, rnd_corner in self.force_corner_rnd_corner:
    #             for shape in self.shapes:
    #                 yield Calibration(prob_rnd, kappa, force_corner, rnd_corner, shape)

    def __iter__(self, desc=''):
        a = []
        for string, parameters in self.grid.items():
            grav_nonuniform, force_corner, rnd_corner = string.split('_')
            for prob_rnd, kappa, color, elastic, forceTotal in parameters:
                for shape in self.shapes:
                    descriptor = f'grav_nonuniform_{grav_nonuniform} force_corner_{force_corner} rnd_corner_{rnd_corner}'
                    a.append([prob_rnd, kappa, grav_nonuniform, force_corner, rnd_corner, shape, elastic, forceTotal, color,
                              descriptor])
        print(f'types of sim ({len(self.grid.keys())}) * shapes ({len(self.shapes)}) * parameters ({len(parameters)})')
        for args in tqdm(a, total=len(a), desc=desc):
            yield Calibration(*args)

    @classmethod
    def same_grids(cls, kappa=8, prob_rnds=0.2, elastic=0, forceTotal=None):
        grids = {shape: {} for shape in shapes}
        for shape in shapes:
            for key in keys:
                # grav_nonuniform, force_on_corner, rnd_corner = key.split('_')
                # string = f'{grav_nonuniform}_{force_on_corner}_{rnd_corner}'
                # kappa = best_values[shape][string]['kappa']
                # prob_rnds = best_values[shape][string]['p']
                grids[shape][key] = [(prob_rnds, kappa, None, elastic, forceTotal)]
        return [cls(grid, [shape]) for shape, grid in grids.items()]

    def best_grids(self, elastic, shapes=shapes, keys=keys):
        with open(mini_SaverDirectories['gillespie'] + f'\\best_values_elastic_{int(elastic)}_new.json', 'r') as f:
            best_values = json.load(f)

        # shape_keys = {'I': ['False_False_False'],
        #               'T': ['False_False_False'],
        #               'H': ['False_False_False', 'False_True_False'],
        #               'LongT': ['False_False_False', 'False_True_False'],
        #               'SPT': ['False_False_False', 'False_True_False', 'True_True_True']
        #               }
        grids = {shape: {} for shape in shapes}
        for shape in shapes:
            for key in keys:
                grav_nonuniform, force_on_corner, rnd_corner = key.split('_')
                string = f'{grav_nonuniform}_{force_on_corner}_{rnd_corner}'
                kappa = best_values[shape][string]['kappa']
                prob_rnds = best_values[shape][string]['p']
                forceTotal = best_values[shape][string]['forceTotal']
                grids[shape][key] = [(prob_rnds, kappa, None, elastic, forceTotal)]
        return [GridIterator(grid, [shape]) for shape, grid in grids.items()]

    @classmethod
    def ant_grids(cls):
        grids = []
        for shape in shapes:
            grav_non = Calibration.similar_to_ants('XL', shape).grav_nonuniform
            f = Calibration.similar_to_ants('XL', shape).force_corner
            r = Calibration.similar_to_ants('XL', shape).rnd_corner
            keys = [f'{grav_non}_{f}_{r}']
            parameters = []
            for size in ['XL', 'M']:
                parameters.append((Calibration.similar_to_ants(size, shape).prob_rnd,
                                   Calibration.similar_to_ants(size, shape).kappa,
                                   None))
            # parameters = [(p, k, None) for (p, k) in product(prob_rnds, kappas)]
            grid = {k: parameters for k in keys}
            grids.append(cls(grid, [shape]))
        return grids

    def get_efficiencies(self, grav_nonuniform, force_corner, rnd_corner, shape, string, elastic):
        # open a dictionary with self.prob_rnds as keys
        eff = {str(p): {str(k): {} for k in self.kappas} for p in self.prob_rnds}
        sem = {str(p): {str(k): {} for k in self.kappas} for p in self.prob_rnds}

        # assert len(self.forceTotal) == 1

        for prob_rnd, kappa, forceTotal in tqdm(product(self.prob_rnds, self.kappas, self.forceTotal),
                                                desc=f'Calculating efficiencies {grav_nonuniform}_{force_corner}_{rnd_corner}',
                                                total=len(self.prob_rnds) * len(self.kappas) * len(self.forceTotal)):
            cal = Calibration(prob_rnd, kappa, grav_nonuniform, force_corner, rnd_corner, shape, elastic, forceTotal)
            hit_stats = HIT_statistics(cal.get_df().copy(), results_folder=cal.folder(), solver_string='gillespie_HIT')

            effs, sems = hit_stats.get_passing_prob(hit_stats.df[hit_stats.df['shape'] == shape], string)
            eff[str(prob_rnd)][str(kappa)][str(forceTotal)], sem[str(prob_rnd)][str(kappa)][str(forceTotal)] = effs['L'], sems['L']

        # Convert nested dictionary to DataFrame with MultiIndex

        # Flatten the nested dictionary into a list of tuples
        eff_data = []
        sem_data = []
        for prob_rnd, kappa_dict in eff.items():
            for kappa, force_dict in kappa_dict.items():
                for forceTotal, value in force_dict.items():
                    eff_data.append((prob_rnd, kappa, forceTotal, value))
                    sem_data.append((prob_rnd, kappa, forceTotal, sem[prob_rnd][kappa][forceTotal]))

        # Create DataFrame
        values_df = pd.DataFrame(eff_data, columns=["prob_rnd", "kappa", "forceTotal", "eff"])
        # Set MultiIndex
        values_df.set_index(["prob_rnd", "kappa", "forceTotal"], inplace=True)

        errors_df = pd.DataFrame(sem_data, columns=["prob_rnd", "kappa", "forceTotal", "sem"])
        errors_df.set_index(["prob_rnd", "kappa", "forceTotal"], inplace=True)

        annot = values_df.apply(lambda x: x.round(1).astype(str)) # + " ± " + errors_df.loc[x.name].round(1).astype(str))

        # annot = values_df.round(1).astype(str) + " ± " + errors_df.round(1).astype(str)
        return values_df, annot

    def plot_grid_of_efficiencies(self, string='pL', elastic=0.0):
        fig, axss = plt.subplots(len(self.shapes), len(self.grid), figsize=(6, 6), sharex=True, sharey=True)
        for axs, shape in zip(axss, shapes):
            for ax, force_on_corner_rnd_corner_str in tqdm(zip(axs, self.grid.keys()),
                                                           desc='Plotting grid of efficiencies',
                                                           total=len(self.grid)):
                grav_nonuniform, force_on_corner, rnd_corner = [eval(s) for s in force_on_corner_rnd_corner_str.split('_')]
                title = sim_names[f'{grav_nonuniform}_{force_on_corner}_{rnd_corner}']
                if shape == 'I':
                    # ax.set_title(title + ': ' + {'I': 'I', 'T': 'T', 'H': 'H', 'LongT': 'T2', 'SPT': 'H2'}[shape], fontsize=8)
                    ax.set_title(title, fontsize=8)
                values_df, annot = self.get_efficiencies(grav_nonuniform, force_on_corner, rnd_corner, shape, string, elastic)

                # in the heatmap, I want that the y axis is the (prob_rnd, forceTotal) and the x axis is the kappa
                # I want to have the color of the heatmap to be the efficiency

                values_df = values_df.unstack(level=1)
                annot = annot.unstack(level=1)

                # Plot heatmap
                sns.heatmap(values_df,
                            annot=annot,
                            cbar=ax == axs[-1],
                            fmt="",
                            cmap="viridis",
                            vmin=0,
                            vmax=1,
                            cbar_kws={'label': 'solution prob.'},
                            annot_kws={"size": 7},  # Adjust font size as nee
                            ax=ax,
                            xticklabels=values_df.columns.get_level_values(1),
                            yticklabels=[f'p={i[0]}' for i in values_df.index]
                            )

                # set the axis labels to r$p$ and r$\kappa$
                if ax == axs[0]:

                    ax.set_ylabel({'I': 'I', 'T': 'T', 'H': 'H', 'LongT': 'T2', 'SPT': 'H2'}[shape])
                else:
                    ax.set_ylabel('')
                if shape == 'SPT':
                    ax.set_xlabel(r'$\kappa$')
                else:
                    ax.set_xlabel('')

                # if ax == axs[-1]:
                #     for size in ['M', 'XL']:
                #         p, kappa = Calibration.similar_to_ants(size, shape).kappa, Calibration.similar_to_ants(size, shape).prob_rnd
                #         row_pos = values_df.index.get_loc(str(p))  # Convert row label to position
                #         col_pos = values_df.columns.get_loc(str(kappa))  # Convert column name to position
                #         ax.text(col_pos + 0.5, row_pos + 0.5, 'ants ' + new_sizing[size],
                #                 color='red', ha='center', va='center', weight='bold',
                #                 fontsize=5)
                #
                # DEBUG = 1

        plt.tight_layout()

    def save_best_values(self, elastic):
        best_values = {shape: {} for shape in shapes}

        for shape in shapes:
            for string in self.grid.keys():
                grav_nonuniform, force_on_corner, rnd_corner = string.split('_')
                values_df, annot = self.get_efficiencies(grav_nonuniform, force_on_corner, rnd_corner, shape, 'pL', elastic)
                max_idx = values_df.stack().idxmax()  # Returns (row_index, column_name)
                # save values in file
                best_values[shape][f'{grav_nonuniform}_{force_on_corner}_{rnd_corner}'] = {'kappa': float(max_idx[1]),
                                                                                            'p': float(max_idx[0]),
                                                                                           'forceTotal': float(max_idx[2])}

        with open(mini_SaverDirectories['gillespie'] + f'\\best_values_elastic_{elastic}_new.json', 'w') as f:
            json.dump(best_values, f)

    def plot_minimal_grid_of_efficiencies(self, shape='H'):
        fig, axs = plt.subplots(1, len(self.grid) + 1, figsize=(9, 4), dpi=300)

        df_ant = get_exp_df()
        hit_stats = HIT_statistics(df_ant, results_folder=mini_SaverDirectories['gillespie'] + '\\HIT_stats\\')
        ant_passing_probability, _ = hit_stats.get_passing_prob(hit_stats.df[hit_stats.df['shape'] == shape], 'pL')
        ant_passing_probability = {key: ant_passing_probability[key] for key in ['M', 'L', 'SL', 'XL']}
        values_df = pd.DataFrame(ant_passing_probability, index=[''])
        values_df.index.name = 'group size'
        sns.heatmap(values_df,  fmt="", cbar=False, cmap="viridis", vmin=0, vmax=1,
                    cbar_kws={'label': r'$P_{\mathrm{slit \rightarrow solution}}$'}, ax=axs[0])
        axs[0].set_title('ant groups (exp.)')
        axs[0].set_ylabel('')

        # remove x-tick
        axs[0].set_yticks([])
        axs[0].set_xticklabels(
            [new_sizing[size] for size in ['M', 'L', 'SL', 'XL']],
            rotation=45,  # Rotate labels 45 degrees
            ha='right'  # Align labels to the right
        )

        for ax, string in zip(axs[1:], self.grid.keys()):
            grav_nonuniform, force_on_corner, rnd_corner = string.split('_')
            title = sim_names[f'{grav_nonuniform}_{force_on_corner}_{rnd_corner}']
            ax.set_title(title)
            values_df, annot = self.get_efficiencies(grav_nonuniform, force_on_corner, rnd_corner, shape, 'pL')

            # Plot heatmap
            sns.heatmap(values_df,
                        # annot=annot,
                        fmt="",
                        cbar=ax==axs[-1],
                        cmap="viridis",
                        vmin=0,
                        vmax=1,
                        cbar_kws={'label': r'$P_{\mathrm{slit \rightarrow solution}}$'},
                        ax=ax)

            # set the axis labels to r$p$ and r$\kappa$
            ax.set_xlabel(r'$\kappa$')
            ax.set_ylabel('')
            # ax.text(col_pos + 0.5, row_pos + 0.5, 'B', color='red', ha='center', va='center', weight='bold', fontsize=20)

            # if ax == axs[-1]:
            #     for size in ['M', 'XL']:
            #         p, kappa = Calibration.similar_to_ants(size, shape)
            #         row_pos = values_df.index.get_loc(str(p))  # Convert row label to position
            #         col_pos = values_df.columns.get_loc(str(kappa))  # Convert column name to position
            #         ax.text(col_pos + 0.5, row_pos + 0.5, 'ants ' + new_sizing[size],
            #                 color='red', ha='center', va='center', weight='bold',
            #                 fontsize=5)

                # DEBUG = 1

        for ax in axs[1:]:
            ax.set_ylabel(r'$p$')
        axs[0].set_xlabel('group size')

        # write (a, b, c) as labels of the subplots
        for i, ax in enumerate(axs):
            ax.text(-0.2, 1.2, chr(97 + i), transform=ax.transAxes,
                    size=12, weight='bold')

        # image_path = os.path.join(mini_SaverDirectories['gillespie'], 'stuck_coordinates.png')
        # image = plt.imread(image_path)
        # image_box = OffsetImage(image, zoom=0.08)  # Adjust zoom to fit your plot
        # annotation_box = AnnotationBbox(image_box, (-0.2, 0.45), frameon=False, xycoords='axes fraction')
        # axs[0].add_artist(annotation_box)

        axs[2].sharex(axs[1])
        axs[3].sharex(axs[1])

        plt.tight_layout()

    def is_elastic(self):
        assert len(np.unique([l[0][-1] for l in self.grid.values()])) == 1
        return bool(int(np.unique([l[0][-1] for l in self.grid.values()])[0]))

    def plot_average_passing_probability(self, ax, string='pL', marker='o'):
        parameters = ''
        df_ant = get_exp_df()
        assert len(self.shapes) == 1
        shape = self.shapes[0]
        for size in shapes_sizes[shape]:
            cal_ants = Calibration.similar_to_ants(size, shape, string)
            hit_stats_ant_sim = HIT_statistics(cal_ants.get_df(),
                                               results_folder=cal_ants.folder(),
                                               solver_string='gillespie_HIT',
                                               descriptor=cal_ants.descriptor,
                                               )

            hit_stats_ant_sim.passing_probability(shape,
                                                  ax=ax,
                                                  labels=[size + ' ant sim.'],
                                                  color=cal_ants.color,
                                                  string=string,
                                                  maxx=maxx[string][shape],
                                                  marker=marker)

            hit_stats_ants_exp = HIT_statistics(df_ant[(df_ant['size'] == size) & (df_ant['shape'] == shape)].copy(),
                                                results_folder=mini_SaverDirectories['gillespie'] + '\\HIT_stats\\',
                                                solver_string='ant_HIT',
                                                descriptor='ant exp. ' + size
                                                )

            hit_stats_ants_exp.passing_probability(shape, ax=ax,
                                                   labels=[size + ' ant exp.'],
                                                   color=color_dict[size + ' ant_HIT'],
                                                   string=string,
                                                   maxx=maxx[string][shape],
                                                   marker='s'
                                                   )
            if self.is_elastic() and size in ['M', 'S']:
                parameters += f'size={size}, shape={shape}, p={cal_ants.prob_rnd}, kappa={cal_ants.kappa}, elastic\n'
            elif not self.is_elastic() and size in ['XL', '', 'L']:
                parameters += f'size={size}, shape={shape}, p={cal_ants.prob_rnd}, kappa={cal_ants.kappa}, inelastic\n'
        # Save the parameters cal_ants.prob_rnd and cal_ants.kappa in a txt file
        with open(os.path.join(mini_SaverDirectories['gillespie'], f'parameters.txt'), 'a') as f:
            f.write(parameters)

        passing_prob = {k: [] for k in self.grid.keys()}
        smaller_grids = {k: GridIterator({k: self.grid[k]}, [shape]) for k in self.grid.keys()}
        for key, smaller_grid in smaller_grids.items():
            for cal in tqdm(smaller_grid, desc='Plotting passing prob. for ' + string, total=len(self)):
                hit_stats = HIT_statistics(cal.get_df(),
                                           results_folder=cal.folder(),
                                           solver_string='gillespie_HIT',
                                           descriptor=cal.descriptor)

                passing_prob[key].append(hit_stats.get_passing_prob(hit_stats.df[hit_stats.df['shape'] == shape], string)[0]['L'] * 100)
            passing_prob[key] = np.mean(passing_prob[key], axis=0)
            ax.errorbar(x_value[cal.descriptor], [passing_prob[key]], yerr=[0], color=cal.color,
                        label=sim_names[str(cal.grav_nonuniform) + '_' + str(cal.force_corner) + '_' +
                                        str(cal.rnd_corner)],
                        marker=marker)
            # combine all the all_hit_stats to one hit_stats




    def plot_passing_probability(self, ax, string='pL', marker='o'):
        parameters = ''
        df_ant = get_exp_df()
        assert len(self.shapes) == 1
        shape = self.shapes[0]
        for size in shapes_sizes[shape]:
            # cal_ants = Calibration.similar_to_ants(size, shape, string)
            # hit_stats_ant_sim = HIT_statistics(cal_ants.get_df(),
            #                                    results_folder=cal_ants.folder(),
            #                                    solver_string='gillespie_HIT',
            #                                    descriptor=cal_ants.descriptor,
            #                                    )
            #
            # hit_stats_ant_sim.passing_probability(shape,
            #                                   ax=ax,
            #                                   labels=[size + ' ant sim.'],
            #                                   color=cal_ants.color,
            #                                   string=string,
            #                                   maxx=maxx[string][shape],
            #                                   marker=marker)


            hit_stats_ants_exp = HIT_statistics(df_ant[(df_ant['size'] == size) & (df_ant['shape'] == shape)].copy(),
                                       results_folder=mini_SaverDirectories['gillespie'] + '\\HIT_stats\\',
                                       solver_string='ant_HIT',
                                       descriptor='ant exp. ' + size
                                       )

            hit_stats_ants_exp.passing_probability(shape, ax=ax,
                                      labels=[size + ' ant exp.'],
                                      color=color_dict[size + ' ant_HIT'],
                                      string=string,
                                      maxx=maxx[string][shape],
                                      marker='s'
                                      )
            # if self.is_elastic() and size in ['M', 'S']:
            #     parameters += f'size={size}, shape={shape}, p={cal_ants.prob_rnd}, kappa={cal_ants.kappa}, elastic\n'
            # elif not self.is_elastic() and size in ['XL', '', 'L']:
            #     parameters += f'size={size}, shape={shape}, p={cal_ants.prob_rnd}, kappa={cal_ants.kappa}, inelastic\n'
        # # Save the parameters cal_ants.prob_rnd and cal_ants.kappa in a txt file
        # with open(os.path.join(mini_SaverDirectories['gillespie'], f'parameters.txt'), 'a') as f:
        #     f.write(parameters)

        for cal in tqdm(self, desc='Plotting CDF for ' + string, total=len(self)):
            hit_stats = HIT_statistics(cal.get_df(), results_folder=cal.folder(), solver_string='gillespie_HIT',
                                       descriptor=cal.descriptor)
            hit_stats.passing_probability(shape,
                                      ax=ax,
                                      labels=[sim_names[str(cal.grav_nonuniform) + '_' + str(cal.force_corner) + '_' + str(cal.rnd_corner)]],
                                      color=cal.color,
                                      string=string,
                                      maxx=maxx[string][shape],
                                      marker=marker
                                      )

    def plot_CDF(self, ax, string='pL', marker='.', max_time={'I': 30, 'T': 30, 'H': 50, 'LongT': 600}):
        df_ant = get_exp_df()
        assert len(self.shapes) == 1
        shape = self.shapes[0]
        parameters = ''
        for size in shapes_sizes[shape]:
            # cal_ants = Calibration.similar_to_ants(size, shape, string)
            # hit_stats_ant_sim = HIT_statistics(cal_ants.get_df(),
            #                                    results_folder=cal_ants.folder(),
            #                                    solver_string='gillespie_HIT')
            #
            # hit_stats_ant_sim.CDF_per_attempt(shape,
            #                                   ax=ax,
            #                                   labels=[size + ' ant sim.'],
            #                                   color=cal_ants.color,
            #                                   string=string,
            #                                   maxx=maxx[string][shape])
            #
            # parameters += f'size={size}, shape={shape}, p={cal_ants.prob_rnd}, kappa={cal_ants.kappa}\n'

            hit_stats_ants_exp = HIT_statistics(df_ant[(df_ant['size'] == size) & (df_ant['shape'] == shape)].copy(),
                                       results_folder=mini_SaverDirectories['gillespie'] + '\\HIT_stats\\',
                                       solver_string='ant_HIT'
                                       )
            hit_stats_ants_exp.CDF_per_attempt(shape, ax=ax,
                                      labels=[size + ' ant exp.'],
                                      color=color_dict[size + ' ant_HIT'],
                                      string=string,
                                      maxx=maxx[string][shape]
                                      )

        # # Save the parameters cal_ants.prob_rnd and cal_ants.kappa in a txt file
        # with open(os.path.join(mini_SaverDirectories['gillespie'], f'parameters.txt'), 'a') as f:
        #     f.write(parameters)

        for cal in tqdm(self, desc='Plotting CDF for ' + string, total=len(self)):
            hit_stats = HIT_statistics(cal.get_df(), results_folder=cal.folder(), solver_string='gillespie_HIT')
            label = str(cal.grav_nonuniform) + ' L ' + str(cal.force_corner) + ' ' + str(cal.rnd_corner)
            hit_stats.CDF_per_attempt(shape,
                                      ax=ax,
                                      labels=[sim_names[label]],
                                      color=cal.color,
                                      string=string,
                                      maxx=maxx[string][shape]
                                      )

        # # get position of legend in the last subplot
        # axs[-1].legend().remove()
        # image_path = os.path.join(mini_SaverDirectories['gillespie'], 'different_force_attachment_points.png')
        # image = plt.imread(image_path)
        # image_box = OffsetImage(image, zoom=0.075)  # Adjust zoom to fit your plot
        # annotation_box = AnnotationBbox(image_box, (2.15, 0.45), frameon=False, xycoords='axes fraction')

        # # Add the image in place of the legend
        # axs[-1].add_artist(annotation_box)

        # how do I cut off the part that is now white?
        # plt.tight_layout()

    def run_grid_simulation(self, num=10, frameNumber=2000, display=False):
        for cal in self.__iter__(desc='Running simulation number ' + str(num)):
            print(str(cal))
            for _ in range(num):
                cal.run_simulation(display=display, frameNumber=frameNumber)


class Calibration:
    def __init__(self, prob_rnd, kappa, grav_nonuniform, force_corner, rnd_corner, shape, elastic, forceTotal, color=None, descriptor=None):
        assert prob_rnd <= 1
        self.prob_rnd = prob_rnd
        self.kappa = int(kappa)
        self.shape = shape
        self.elastic = elastic
        self.forceTotal = forceTotal
        if self.forceTotal == 4.0:
            self.forceTotal = 4
        self.descriptor = descriptor

        if type(grav_nonuniform) == str:
            self.grav_nonuniform = eval(grav_nonuniform)
        else:
            self.grav_nonuniform = grav_nonuniform

        if type(force_corner) == str:
            self.force_corner = eval(force_corner)
        else:
            self.force_corner = force_corner

        if type(rnd_corner) == str:
            self.rnd_corner = eval(rnd_corner)
        else:
            self.rnd_corner = rnd_corner
        string = f'{self.grav_nonuniform}_{self.force_corner}_{self.rnd_corner}'
        if color is None:
            # 'Uniform gravitation':
            if string == 'False_False_False':
                self.color = '#A9A9A9'  # Dark gray (no effects)
            elif string == 'True_False_False':
                self.color = '#006400'  # Dark green (gravity only)
            elif string == 'True_True_False':
                self.color = '#1E90FF'  # Bright blue (gravity + force)
            elif string == 'True_True_True':
                self.color = '#87CEFA'  # Light sky blue (gravity + force + randomness)
            elif string == 'False_True_False':
                self.color = '#B22222'  # Firebrick red (force only)
            elif string == 'False_True_True':
                self.color = '#FF6347'  # Tomato (force + randomness)
            else:
                raise ValueError('Invalid string')
        else:
            self.color = color

    def __str__(self):
        return (f'grav_nonuniform={self.grav_nonuniform}, '
                f'force_corner={self.force_corner}, '
                f'rnd_corner={self.rnd_corner}, {self.shape}, '
                f'prob_rnd={self.prob_rnd}, '
                f'kappa={self.kappa}, '
                f'forceTotal={self.forceTotal}, '
                f'elastic={self.elastic}, '
                )

    @classmethod
    def similar_to_ants_old(cls, size, shape):
        N_ants = {'M': {'I': 8, 'T': 12, 'H': 14}, 'XL': {'I': 43, 'T': 38, 'H': 56}}
        attachment_rate_per_site = 0.015
        p = attachment_rate_per_site * N_ants[size][shape] * 0.5
        kappa = 3
        size_to_color = {'XL': '#c89bff', 'M': '#ffd884'}
        color = size_to_color.get(size)
        return cls(p, kappa, True, True, False ,shape, color)

    @classmethod
    def similar_to_ants(cls, size, shape, string):
        kappa_small = 3
        kappa_large = 9
        elastic_large = 0
        elastic_small = 1
        forceTotal_large = 0.5
        forceTotal_small = 4
        p_small = 0.2 / 5
        p_large = 0.2 / 1
        color = {'XL': '#c89bff', 'M': '#ffd884', '': '#c89bff', 'S': '#ffd884'}.get(size)

        if size in ['M', 'S']:
            return cls(p_small, kappa_small, True, True, True,
                                'SPT', elastic_small, forceTotal_small)
        elif size in ['XL', 'L', '', '']:
            return cls(p_large, kappa_large, True, True, True,
                                'H', elastic_large, forceTotal_large)
        else:
            raise ValueError('Invalid size')
        # elastic = {'S': 1, 'M': 1, 'XL': 0, 'L': 0, '': 0}.get(size)
        # assert elastic is not None, f'{size} not in {elastic}'
        # with open(os.path.join(home, 'Gillespie', f'min_distance_CDFs_{string}_elastic_{elastic}.json'), 'r') as f:
        #     min_dist = json.load(f)
        #
        # assert size in min_dist[shape].keys()
        #
        # parameters = min_dist[shape][size]
        # p = eval(parameters.split('prob_rnd=')[1].split(', ')[0])
        # kappa = eval(parameters.split('kappa=')[1].split(', ')[0])
        #
        # return cls(p, kappa, True, True, True, shape, elastic, color,
        #            descriptor='sim. fitted to ants ' + size)


    def run_analytics(self):
        df = self.get_df()
        assert len(df) > 0, 'No simulations to analyze in ' + str(self)
        hit_stats = HIT_statistics(df, results_folder=self.folder(), solver_string='gillespie_HIT')

        # find filenames that do not have indices_of_attempt
        hit_stats.indices_of_attempts()
        hit_stats.pL_per_attempt()
        # hit_stats.time_per_attempt()
        self.check_validity_of_folder()

    def folder(self):
        cal_str = f'kappa_{self.kappa}_prob_rnd_{self.prob_rnd}'
        folder = os.path.join(os.getcwd(), 'results')

        # create a new folder
        if not os.path.isdir(folder):
            folders = [f for f in folder.split('\\')]
            for i in range(6, len(folders) + 1):
                if not os.path.isdir('\\'.join(folders[:i])):
                    os.mkdir('\\'.join(folders[:i]))

        # save empty dataframe
        if not os.path.isfile(os.path.join(folder, 'df_gillespie.xlsx')):
            pd.DataFrame().to_excel(os.path.join(folder, 'df_gillespie.xlsx'))

        return folder

    def get_pickled_filenames(self):
        return [file for file in os.listdir(self.folder()) if not np.any([file.__contains__(key)
                        for key in ['.json', '.png', '.xlsx', '.txt', '.pdf', '.pkl', '.svg']])]

    def update_df(self):
        df = self.get_df()
        new_filenames = self.get_pickled_filenames()
        if len(df) > 0:
            new_filenames = [file for file in new_filenames if not file in list(df['filename'])]

        df = pd.concat([df, pd.DataFrame(new_filenames, columns=['filename'])], axis=0)
        df['size'] = df['filename'].apply(lambda x: x.split('_')[0])
        df['shape'] = df['filename'].apply(lambda x: x.split('_')[1])
        df['winner'] = df['filename'].apply(lambda x: not 'failed' in x)
        df['solver'] = 'Gillespie'

        # avoid the Unnamed: 0 column
        df = df.loc[:, ~df.columns.str.contains('^Unnamed')]
        # update the index
        df = df.reset_index(drop=True)
        df.to_excel(os.path.join(self.folder(), 'df_gillespie.xlsx'))

    def delete_sims(self):
        # find all the simulations
        files = [file for file in os.listdir(self.folder())
                 if not np.any([file.__contains__(key)
                                for key in ['.json', '.png', '.xlsx', '.txt', '.pdf', '.pkl', '.svg']])]

        for filename in files:
            file_path = os.path.join(self.folder(), filename)
            try:
                if os.path.isfile(file_path):
                    os.remove(file_path)  # Delete the file
                    print(f"Deleted: {filename}")
            except Exception as e:
                print(f"Failed to delete {filename}: {e}")

    def find_valid_sims(self):
        # num_valid_sims = \
        #     len([file for file in os.listdir(self.folder())
        #      if file.startswith('L_' + self.shape) and not file.__contains__('.json')])

        df = self.get_df()
        if len(df) == 0:
            return 0
        num_valid_sims = len(df[df['shape'] == self.shape])
        return num_valid_sims

    def check_validity_of_folder(self):
        df = self.get_df()

        names = ['gillespie_HIT_pL_per_attempt.json',
                 'gillespie_HIT_pL_not_attempt.json',
                 # 'gillespie_HIT_time_per_attempt.json',
                 # 'gillespie_HIT_time_not_attempt.json'
                ]
        for name in names:
            with open(os.path.join(self.folder(), name), 'r') as f:
                file = json.load(f)

            # remove from df all that are not in file.keys
            assert len(set(list(file.keys())) - set(list(df['filename']))) == 0
            assert len(set(list(df['filename'])) - set(list(file.keys()))) == 0

    def get_df(self):
        df = pd.read_excel(os.path.join(self.folder(), 'df_gillespie.xlsx'))
        if len(df) == 0:
            print(f'No simulations in {self.folder()}')
        return df

    def new_filename(self):
        df = self.get_df()
        if len(df) == 0:
            n = 0
        else:
            df = df[df['shape'] == self.shape]
            if len(df) == 0:
                n = 1
            else:
                n = df['filename'].apply(lambda x: int(x.split('_')[2])).max() + 1

        assert not np.isnan(n)

        return size + '_' + self.shape + '_' + str(n) + '_' + \
               f'kappa_{self.kappa}_prob_rnd_{self.prob_rnd}' + '_' + datetime.now().strftime("%H-%M-%S")

    def run_simulation(self, display=True, frameNumber=5000, save=True, videowriter=False):
        x = Trajectory_gillespie(size=size, shape=self.shape,
                                 filename=self.new_filename(),
                                 forceTotal=self.forceTotal,
                                 time_step=time_step,
                                 prob_rnd=self.prob_rnd,
                                 kappa=self.kappa,
                                 fps=1 / time_step,
                                 grav_nonuniform=self.grav_nonuniform,
                                 force_on_corner=self.force_corner,
                                 rnd_corner=self.rnd_corner,
                                 elastic=self.elastic
                                 )
        x.run_gravitational_simulation(frameNumber =frameNumber,
                                       display=display,
                                       videowriter=videowriter)

        if save:
            address = self.folder() + '\\' + x.filename
            x.save(address=address)
            print(address)
            self.update_df()

prob_rnds = [0.05, 0.2, 0.4]  # 1
kappas = [1, 5, 8]  # , 32
sizes = ['L']
elastic = [0, 1]

# what do I want to do...
# I want to have 50 simulations of every calibration
parameters = [(p, k, None) for (p, k) in product(prob_rnds, kappas)]

# cal = Calibration(0.1, 2, True, True, True,'LongT')
# for _ in range(50):
#     cal.run_simulation(display=True, frameNumber=10000, save=False)

# ant_grids = GridIterator.ant_grids()
# for ant_grid in ant_grids:
#     ant_grid.run_grid_simulation(num=50, display=False)
#     for cal in ant_grid:
#         cal.run_analytics()
#         cal.delete_sims()


if __name__ == '__main__':
    # set the constant calibration values
    # what do I want to do...
    # I want to have 50 simulations of every calibration
    parameters = [(p, k, None, e) for (p, k, e) in product(prob_rnds, kappas, elastic)]

    # cal = Calibration(0.2, 1, True, False, False,'SPT')
    # cal_XL = Calibration.similar_to_ants('XL', 'H', 'pL')
    # cal_M = Calibration.similar_to_ants('M', 'H', 'pL')
    #

    # set random seed
    np.random.seed(1)

    cal_M = Calibration(0.2, 1, False, True, False, 'SPT', 0, 4)
    for _ in tqdm(range(25), total=25):
        cal_M.run_simulation(display=True, frameNumber=10000, save=False)
    #     # cal_M.run_simulation(display=True, frameNumber=10000, save=False, mass=4)

    # ant_grids = GridIterator.ant_grids()
    # for ant_grid in ant_grids:
    #     ant_grid.run_grid_simulation(num=50, display=False)
    #     for cal in ant_grid:
    #         cal.run_analytics()
    #         cal.delete_sims()

    #
    # grid = {k: parameters for k in keys}
    # grid_iterator = GridIterator(grid, shapes)
    # grid_iterator.run_grid_simulation(num=25, display=False)
    # for cal in grid_iterator:
    #     cal.run_analytics()
    #     cal.delete_sims()
    #
    # grid_iterator.plot_grid_of_efficiencies()
    # plt.savefig(os.path.join(mini_SaverDirectories['gillespie'], 'heatmap_grid.pdf'))
    #
    # grid_iterator.plot_minimal_grid_of_efficiencies()
    # plt.savefig(os.path.join(mini_SaverDirectories['gillespie'], 'heatmap_grid_minimal.pdf'))
