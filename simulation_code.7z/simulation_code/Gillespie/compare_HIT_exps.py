import matplotlib.pyplot as plt

from Gillespie.grid import *
from Gillespie.HIT_stats import maxx
# from scipy.stats import wasserstein_distance

def total_variation_distance(x, cdf1, cdf2):
    """
    Compute the Total Variation Distance between two CDFs.

    Parameters:
    x (array-like): Points where the CDFs are evaluated.
    cdf1 (array-like): Values of the first CDF.
    cdf2 (array-like): Values of the second CDF.

    Returns:
    float: Total Variation Distance.
    """
    x = np.asarray(x)
    cdf1 = np.asarray(cdf1)
    cdf2 = np.asarray(cdf2)

    # Compute the absolute difference between the CDFs
    abs_diff = np.abs(cdf1 - cdf2)

    # Approximate the integral using the trapezoidal rule
    tv_distance = 0.5 * np.trapz(abs_diff, x)

    return tv_distance


# I want to load the CDFs of the ant experiments and gillespie
class Compare:
    def __init__(self, grid1, grid2):
        self.grid1 = grid1
        self.grid2 = grid2

    def save_grid_distances(self, string, elastic):
        dist = {shape: {size_exp: {} for size_exp in self.grid2.shapes_sizes[shape]} for shape in shapes}
        for size_exp, shape in self.grid2:
            for cal_sim in self.grid1.__iter__(size_exp + ' ' + shape + f', saving dist to exp. {string}'):
                if cal_sim.shape != shape:
                    continue
                hit_stats_sim, hit_stats_exp = self.get_hit_stats(cal_sim, shape, size_exp)
                dist[shape][size_exp][str(cal_sim)] = self.get_distance_CDFs(hit_stats_sim, hit_stats_exp, size_exp, shape, string)

        # save dist in json file
        with open(f'distance_CDFs_{string}_elastic_{elastic}.json', 'w') as f:
            json.dump(dist, f)

    def find_smallest_distance_for_each_shape_and_size(self, string, elastic):
        with open(f'distance_CDFs_{string}_elastic_{elastic}.json', 'r') as f:
            dist = json.load(f)

        min_dist = {shape: {} for shape in shapes}

        for shape in shapes:
            for size_exp in self.grid2.shapes_sizes[shape]:
                min_dist[shape][size_exp] = min(dist[shape][size_exp].items(), key=lambda x: x[1])[0]

        with open(f'min_distance_CDFs_{string}_elastic_{elastic}.json', 'w') as f:
            json.dump(min_dist, f)

    def get_hit_stats(self, cal_sim, shape, size_exp):
        df_ant = get_exp_df()
        df_ant = df_ant[df_ant['size'] == size_exp]
        df_ant = df_ant[df_ant['shape'] == shape]
        hit_stats_exp = HIT_statistics(df_ant.copy(),
                                       results_folder=mini_SaverDirectories['gillespie'] + '\\HIT_stats\\',
                                       solver_string='ant_HIT')

        hit_stats_sim = HIT_statistics(cal_sim.get_df(),
                                       results_folder=cal_sim.folder(),
                                       solver_string='gillespie_HIT')

        return hit_stats_sim, hit_stats_exp

    @staticmethod
    def get_distance_CDFs(hit_stats_sim, hit_stats_exp, size_exp, shape, string):
        sorted_lengths1, y_values_solved1, _, _, _ = (
            hit_stats_sim.get_CDF_per_attempt('L', shape, maxx=maxx[string][shape], string=string))
        sorted_lengths2, y_values_solved2, _, _, _ = (
            hit_stats_exp.get_CDF_per_attempt(size_exp, shape, maxx=maxx[string][shape], string=string))

        if len(sorted_lengths1) == 0 or len(sorted_lengths2) == 0:
            return np.inf

        # how can I get the wasserstein distance though sorted_lengths1 and sorted_lengths2 are not the same?
        common_x = np.linspace(min(sorted_lengths1[0], sorted_lengths2[0]), max(sorted_lengths1[-1], sorted_lengths2[-1]), num=1000)
        y_values_solved1_interp = np.interp(common_x, sorted_lengths1, y_values_solved1)
        y_values_solved2_interp = np.interp(common_x, sorted_lengths2, y_values_solved2)

        # calculate the wasserstein distance
        dist = total_variation_distance(common_x, y_values_solved1_interp, y_values_solved2_interp)
        return dist

class GridIterator_exp:
    def __init__(self, size_exp):
       if size_exp in ['S', 'M']:
            self.shapes_sizes = {'I': ['M'], 'T': ['M'], 'LongT': [], 'H': ['M'], 'SPT': ['S']}
       elif size_exp in ['L', 'XL', '']:
            self.shapes_sizes = {'I': ['XL'], 'T': ['XL'], 'LongT': [''], 'H': ['XL'], 'SPT': ['XL']}

    def __iter__(self):
        for shape, sizes in self.shapes_sizes.items():
            for size in sizes:
                yield size, shape


if __name__ == '__main__':
    parameters = [(p, k, None) for (p, k) in product(prob_rnds, kappas)]

    grid = {k: parameters for k in keys}
    grid_iterator = GridIterator(grid, shapes)
    # grid_iterator.run_grid_simulation(num=25, display=False)
    # for cal in grid_iterator:
    #     cal.run_analytics()
    #     cal.delete_sims()
    #
    # grid_iterator.plot_grid_of_efficiencies(string='pL')
    # plt.savefig(os.path.join(mini_SaverDirectories['gillespie'], 'heatmap_grid.pdf'))
    #
    # grid_iterator.plot_minimal_grid_of_efficiencies()
    # plt.savefig(os.path.join(mini_SaverDirectories['gillespie'], 'heatmap_grid_minimal.pdf'))
    #
    # keys = ['_'.join(map(str, item)) for item in [(True, True, True)]]
    # parameters = [(p, k, None) for (p, k) in product(prob_rnds, kappas)]
    # grid_sim = GridIterator({k: parameters for k in keys}, shapes)
    # #
    # grid_exp = GridIterator_exp()
    # comp = Compare(grid_sim, grid_exp)
    # comp.save_grid_distances('pL')
    # comp.find_smallest_distance_for_each_shape_and_size('pL')
    #
    # # grid_iterator.save_best_values()
    # same_parameters = False
    # grid = {}
    best_grids = GridIterator.best_grids()

    fig, axs = plt.subplots(1, len(shapes), figsize=(10, 3), dpi=300, sharey=True)
    # leave o space betweetn subplots
    # flatten axs
    # Save the parameters cal_ants.prob_rnd and cal_ants.kappa in a txt file
    with open(os.path.join(mini_SaverDirectories['gillespie'], f'parameters.txt'), 'a') as f:
        f.write('')

    for best_grid, ax in zip(best_grids, axs):
        # best_grid.plot_CDF(ax, string='pL')
        best_grid.plot_passing_probability(ax, string='pL')

    # HIT_statistics.finish_CDF_subplots('pL', axs)
    HIT_statistics.finish_passing_probability_subplots(axs)
    plt.tight_layout()
    plt.subplots_adjust(hspace=0.1, wspace=0.1)
    #
    # plt.savefig(os.path.join(mini_SaverDirectories['gillespie'], f'Fig3_all.pdf'))
    plt.savefig(os.path.join(mini_SaverDirectories['gillespie'], f'Fig3_short_2rows.pdf'))
