import numpy as np

from Gillespie.grid import *
from Gillespie.compare_HIT_exps import *
import os
from Gillespie.HIT_stats import exit_size
import json

print(maxx['pL'])

with open(os.path.join('C:\\Users\\tabea\\PycharmProjects', 'Puzzle_collective_transport', 'ConfigSpace', 'minimal_pL.json'), 'r') as f:
    new = json.load(f)

min_times = 4

maxx['pL_minimal'] = {}
for key, value in new.items():
    shape = key.split('_')[0]
    if key.split('_')[1] == 'XL':
        maxx['pL_minimal'][shape] = value / 2 / exit_size[shape]['L']
    elif key.split('_')[1] in ['', 'L']:
        maxx['pL_minimal'][key.split('_')[0]] = value / exit_size[shape]['L']

# for shape in ['I', 'T', 'H', 'LongT', 'SPT']:
#     print(f'maximal path length for {shape}: {maxx["pL"][shape]/maxx["pL_minimal"][shape]:.2f}')

from matplotlib.offsetbox import OffsetImage, AnnotationBbox

def plot_passing_probability_of_all_parameters():
    prob_rnds = [0.05, 0.2, 0.4]
    kappas = [1, 5, 8]

    fig, axs = plt.subplots(1, len(shapes), figsize=(10, 3), dpi=300, sharey=True)
    grid_elastic = {k: [(p, k, None, e) for (p, k, e) in product(prob_rnds, kappas, [1])] for k in keys}
    grid_inelastic = {k: [(p, k, None, e) for (p, k, e) in product(prob_rnds, kappas, [0])] for k in keys}
    for shape, ax in zip(shapes, axs):
        grid_iterator_elastic = GridIterator(grid_elastic, [shape])
        grid_iterator_elastic.plot_average_passing_probability(ax, string='pL', marker='o')

        grid_iterator_inelastic = GridIterator(grid_inelastic, [shape])
        grid_iterator_inelastic.plot_average_passing_probability(ax, string='pL', marker='x')

    HIT_statistics.finish_CDF_subplots('pL', axs)
    plt.tight_layout()
    plt.subplots_adjust(hspace=0.1, wspace=0.1)
    plt.savefig(os.path.join(mini_SaverDirectories['gillespie'], f'Fig3_average.pdf'))
    plt.close()

def get_exp_defined_grid():
    kappa_small = Calibration.similar_to_ants('S', 'I', 'pL').kappa
    kappa_large = Calibration.similar_to_ants('XL', 'I', 'pL').kappa
    elastic_large = 0
    elastic_small = 1
    forceTotal_small = Calibration.similar_to_ants('S', 'I', 'pL').forceTotal
    forceTotal_large = Calibration.similar_to_ants('XL', 'I', 'pL').forceTotal
    p_small = Calibration.similar_to_ants('S', 'I', 'pL').prob_rnd
    p_large = Calibration.similar_to_ants('XL', 'I', 'pL').prob_rnd
    parameters = [(p_small, kappa_small, None, elastic_small, forceTotal_small), (p_large, kappa_large, None, elastic_large, forceTotal_large)]
    # parameters = [(p, k, None, e) for (p, k, e) in product(prob_rnds, kappas, elastic)]
    # keys = ['False_False_False', 'False_True_False', 'True_True_True']
    grid = {k: parameters for k in keys}
    grid_iterator = GridIterator(grid, shapes)
    return grid_iterator

def get_grids(elastic):
    kappa_small = Calibration.similar_to_ants('S', 'I', 'pL').kappa
    forceTotal_small = Calibration.similar_to_ants('S', 'I', 'pL').forceTotal
    elastic_small = 1
    p_small = Calibration.similar_to_ants('S', 'I', 'pL').prob_rnd

    kappa_large = Calibration.similar_to_ants('XL', 'I', 'pL').kappa
    forceTotal_large = Calibration.similar_to_ants('XL', 'I', 'pL').forceTotal
    elastic_large = 0
    p_large = Calibration.similar_to_ants('XL', 'I', 'pL').prob_rnd

    kappas = [1, kappa_small, 5, kappa_large]
    prob_rnds = [p_small, p_large]

    if elastic:
        parameters_small = [(p, k, None, elastic_small, forceTotal_small) for (p, k) in product(prob_rnds, kappas)]
        grid_iterator_small = GridIterator({k: parameters_small for k in keys}, shapes)
        return grid_iterator_small

    elif not elastic:
        parameters_large = [(p, k, None, elastic_large, forceTotal_large) for (p, k) in product(prob_rnds, kappas)]
        grid_iterator_large = GridIterator({k: parameters_large for k in keys}, shapes)
        return grid_iterator_large

def save_simulation_video():
    for shape in ['I', 'H']:
        kappa_small, kappa_large = (Calibration.similar_to_ants('S', shape, 'pL').kappa,
                                    Calibration.similar_to_ants('XL', shape, 'pL').kappa)
        elastic_small, elastic_large = 1, 0
        forceTotal_small, forceTotal_large = (Calibration.similar_to_ants('S', shape, 'pL').forceTotal,
                                              Calibration.similar_to_ants('XL', shape, 'pL').forceTotal)
        p_small, p_large = (Calibration.similar_to_ants('S', shape, 'pL').prob_rnd,
                            Calibration.similar_to_ants('XL', shape, 'pL').prob_rnd)
    
        cal_S = Calibration(p_small, kappa_small, False, False, False, shape, elastic_small, forceTotal_small)
        cal_L = Calibration(p_small, kappa_large, False, False, False, shape, elastic_large, forceTotal_large)
        for _ in tqdm(range(2), total=2, desc=f'saving videos for shape {shape}'):
            cal_L.run_simulation(display=True, frameNumber=10000, save=False, videowriter=True)
            cal_S.run_simulation(display=True, frameNumber=10000, save=False, videowriter=True)

def play_sim():
    kappa_small, kappa_large = (Calibration.similar_to_ants('S', 'I', 'pL').kappa,
                                Calibration.similar_to_ants('XL', 'I', 'pL').kappa)
    elastic_small, elastic_large = 1, 0
    forceTotal_small, forceTotal_large = (Calibration.similar_to_ants('S', 'I', 'pL').forceTotal,
                                          Calibration.similar_to_ants('XL', 'I', 'pL').forceTotal)
    p_small, p_large = (Calibration.similar_to_ants('S', 'I', 'pL').prob_rnd,
                        Calibration.similar_to_ants('XL', 'I', 'pL').prob_rnd)

    cal_S = Calibration(p_small, kappa_small, True, True, True, 'SPT', elastic_small, forceTotal_small)
    cal_L = Calibration(p_small, kappa_large, True, True, True, 'SPT', elastic_large, forceTotal_large)
    for _ in tqdm(range(25), total=25):
        # cal_L.run_simulation(display=True, frameNumber=10000, save=False)
        cal_S.run_simulation(display=True, frameNumber=10000, save=False)


def run_simulations(n = 20):
    # grid_iterator_exp = get_exp_defined_grid()
    grid_elastic = get_grids(1)
    grid_inelastic = get_grids(0)
    for i in range(1, n):
        grid_inelastic.run_grid_simulation(num=i, display=True)
        grid_elastic.run_grid_simulation(num=i, display=True)
    # for cal in grid_elastic:
    #     cal.run_analytics()
    #     # cal.delete_sims()
    # for cal in grid_inelastic:
    #     cal.run_analytics()
    #     # cal.delete_sims()
    # for cal in grid_iterator_exp:
    #     cal.run_analytics()
    #     # cal.delete_sims()
    #
    # def save_exp_in_csv(self):
    #     df = self.get_df()


def save_data_for_online():
    df_ant = get_exp_df()
    hit_stats = HIT_statistics(df_ant,
                               results_folder=mini_SaverDirectories['gillespie'] + '\\HIT_stats\\',
                               solver_string='ant_HIT')

    # find filenames that do not have indices_of_attempt
    hit_stats.indices_of_attempts()
    hit_stats.correct_filenames()

    # hit_stats.save_coords_in_csv()

    # hit_stats.pL_per_attempt()
    # # hit_stats.time_per_attempt()
    # self.check_validity_of_folder()



def wall_following():
    calc_sim(thresh=0.1)
    plot()
    plt.savefig(os.path.join(mini_SaverDirectories['gillespie'], f'sliding.svg'))
    plt.savefig(os.path.join(mini_SaverDirectories['gillespie'], f'sliding.pdf'))
    plt.close()


def save_best_grids():

    for elastic in [0, 1]:
        grid_iterator = get_grids(elastic)
        grid_iterator.save_best_values(elastic=elastic)

def heatmaps():
    for elastic in [0, 1]:
        grid_iterator= get_grids(elastic)
        grid_iterator.plot_grid_of_efficiencies(string='pL', elastic=elastic)
        plt.savefig(os.path.join(mini_SaverDirectories['gillespie'], f'heatmap_grid_elastic_{elastic}.pdf'))


def performance_plots():
    grids_inelastic_best = get_grids(0).best_grids(elastic=0)
    grids_elastic_best = get_grids(1).best_grids(elastic=1)

    cal_inelastic = Calibration.similar_to_ants(size='XL', shape='I', string='pL')
    cal_elastic = Calibration.similar_to_ants(size='S', shape='I', string='pL')
    grids_inelastic_same = GridIterator.same_grids(kappa=cal_inelastic.kappa,
                                              prob_rnds=cal_inelastic.prob_rnd,
                                              elastic=cal_inelastic.elastic,
                                              forceTotal=cal_inelastic.forceTotal)
    grids_elastic_same = GridIterator.same_grids(kappa=cal_elastic.kappa,
                                            prob_rnds=cal_elastic.prob_rnd,
                                            elastic=cal_elastic.elastic,
                                            forceTotal=cal_elastic.forceTotal)

    for string in ['pL']:
        fig, axs_prob = plt.subplots(2, len(shapes), figsize=(10, 10), dpi=300, sharey=True)
        # fig, axs_CDF = plt.subplots(2, len(shapes), figsize=(10, 4), dpi=300, sharey=True)
        axs_CDF = np.zeros_like(axs_prob)

        for grid_inelastic, grid_elastic, ax_prob, ax_CDF in zip(grids_inelastic_same, grids_elastic_same, axs_prob[0], axs_CDF[0]):
            # best_grid.plot_CDF(ax, string='pL')
            grid_inelastic.plot_passing_probability(ax_prob, string=string, marker='x')
            grid_elastic.plot_passing_probability(ax_prob, string=string, marker='o')

            # grid_inelastic.plot_CDF(ax_CDF, string=string, marker='x')
            # grid_elastic.plot_CDF(ax_CDF, string=string, marker='o')

        for grid_inelastic, grid_elastic, ax_prob, ax_CDF in zip(grids_inelastic_best, grids_elastic_best, axs_prob[1], axs_CDF[1]):
            # best_grid.plot_CDF(ax, string='pL')
            grid_inelastic.plot_passing_probability(ax_prob, string=string, marker='x')
            grid_elastic.plot_passing_probability(ax_prob, string=string, marker='o')

            # grid_inelastic.plot_CDF(ax_CDF, string=string, marker='x')
            # grid_elastic.plot_CDF(ax_CDF, string=string, marker='o')

        # HIT_statistics.finish_CDF_subplots(string, axs_CDF[0])
        # HIT_statistics.finish_CDF_subplots(string, axs_CDF[1], subplot_labels=('f', 'g', 'h', 'i', 'j'), legend=False)
        # plt.subplots_adjust(hspace=0.1, wspace=0.1)
        # plt.tight_layout()
        # plt.savefig(os.path.join(mini_SaverDirectories['gillespie'], f'Fig3_best_and_same_parameters_CDF_{string}.pdf'))
        # plt.close()

        HIT_statistics.finish_passing_probability_subplots(axs_prob[0])
        HIT_statistics.finish_passing_probability_subplots(axs_prob[1], subplot_labels=('f', 'g', 'h', 'i', 'j'), legend=False)

        # write on the side of axs[0, -1] 'performance of simulations with the same parameters for all puzzles inspired by ants'
        axs_prob[0, -1].text(1.05, 0.5,
                             'same parameters \nfor all puzzles inspired by ants',
                             va='center', ha='left', rotation=0, transform=axs_prob[0, -1].transAxes)

        axs_prob[0, -1].text(0.9, 0.9,
                             'better than best\nexp. ant group',
                             va='top', ha='right', rotation=0, transform=axs_prob[0, -1].transAxes, color='green')
        axs_prob[0, -1].text(0.1, 0.5,
                             'worse than best\nexp. ant group',
                             va='center', ha='left', rotation=0, transform=axs_prob[0, -1].transAxes, color='red')

        # write on the side of axs[1, -1] 'performance of simulations with the best performance on parameter grid'
        axs_prob[1, -1].text(1.05, 0.5,
                             'parameters of best performance \non parameter grid',
                             va='center', ha='left', rotation=0, transform=axs_prob[1, -1].transAxes)
        plt.subplots_adjust(hspace=0.1, wspace=0.1)

        plt.tight_layout()
        plt.savefig(os.path.join(mini_SaverDirectories['gillespie'], f'Fig3_best_and_same_parameters_prob_{string}.pdf'))
        plt.savefig(os.path.join(mini_SaverDirectories['gillespie'], f'Fig3_best_and_same_parameters_prob_{string}.svg'))


def new_performance_plots():
    shapes = ['I', 'T', 'H', 'LongT', 'SPT']
    shapes_small = ['I', 'T', 'H', 'SPT']
    grids_inelastic_best = get_grids(0).best_grids(elastic=0)
    grids_elastic_best = get_grids(1).best_grids(elastic=1)

    cal_inelastic = Calibration.similar_to_ants(size='XL', shape='I', string='pL')
    cal_elastic = Calibration.similar_to_ants(size='S', shape='I', string='pL')
    grids_inelastic_same = GridIterator.same_grids(kappa=cal_inelastic.kappa,
                                              prob_rnds=cal_inelastic.prob_rnd,
                                              elastic=cal_inelastic.elastic,
                                              forceTotal=cal_inelastic.forceTotal)
    grids_elastic_same = GridIterator.same_grids(kappa=cal_elastic.kappa,
                                            prob_rnds=cal_elastic.prob_rnd,
                                            elastic=cal_elastic.elastic,
                                            forceTotal=cal_elastic.forceTotal)

    keys_to_plot = ['False_False_False', 'False_True_False', 'False_True_True', 'True_True_True']
    fig, (axs_prob_inelastic, axs_prob_elastic) = plt.subplots(2, len(keys_to_plot), figsize=(10, 7), dpi=300, sharey=True)


    for key, ax_inelastic, ax_elastic in zip(keys_to_plot, axs_prob_inelastic, axs_prob_elastic):
        y_values = {}
        for i, shape in enumerate(shapes):
            grid_exp = GridIterator_exp('L')
            df_ant = get_exp_df()
            exp_size = grid_exp.shapes_sizes[shape][0]
            hit_stats_ants_exp = HIT_statistics(df_ant[(df_ant['size'] == exp_size) & (df_ant['shape'] == shape)].copy(),
                                                results_folder=mini_SaverDirectories['gillespie'] + '\\HIT_stats\\',
                                                solver_string='ant_HIT',
                                                descriptor='ant exp. ' + size
                                                )
            sorted_lengths, y_values_solved, y_values_giveup, error_bar_solved, error_bar_giveup = (
                hit_stats_ants_exp.get_CDF_per_attempt(exp_size, shape, maxx=maxx['pL'][shape], string='pL'))
                # hit_stats_ants_exp.get_CDF_per_attempt(exp_size, shape, maxx=min_times * maxx['pL_minimal'][shape], string='pL'))
            # print('beware, this is a non-normalized CDF')

            y_values[shape] = y_values_solved[-1]
        ax_inelastic.step(range(len(shapes)), y_values.values(), where='mid', color=color_dict['XL ant_HIT'],
                          linestyle='--', label='large ant\ngroup (exp.)')
        ax_inelastic.fill_between(range(len(shapes)), 0, y_values.values(), alpha=0.1, color='black')

        y_values = {}
        for i, shape in enumerate(shapes_small):
            grid_exp = GridIterator_exp('S')
            df_ant = get_exp_df()
            exp_size = grid_exp.shapes_sizes[shape][0]
            hit_stats_ants_exp = HIT_statistics(df_ant[(df_ant['size'] == exp_size) & (df_ant['shape'] == shape)].copy(),
                                                results_folder=mini_SaverDirectories['gillespie'] + '\\HIT_stats\\',
                                                solver_string='ant_HIT',
                                                descriptor='ant exp. ' + size
                                                )
            sorted_lengths, y_values_solved, y_values_giveup, error_bar_solved, error_bar_giveup = (
                # hit_stats_ants_exp.get_CDF_per_attempt(exp_size, shape, maxx=min_times * maxx['pL_minimal'][shape], string='pL'))
                hit_stats_ants_exp.get_CDF_per_attempt(exp_size, shape, maxx=maxx['pL'][shape], string='pL'))


            y_values[shape] = y_values_solved[-1]
        ax_elastic.step(range(len(shapes_small)), y_values.values(), where='mid', color=color_dict['M ant_HIT'], linestyle='--', label='small ant\ngroup (exp.)')
        ax_elastic.fill_between(range(len(shapes_small)), 0, y_values.values(), alpha=0.1, color='black')

        # now I want to plot the performance of the simulations
        for grids, label, color, shift in tqdm(zip(
                [grids_inelastic_best, grids_inelastic_same],
                ['best performing\nsimulation', 'fixed-param.\nsimulation'],
                ['red', 'blue'],
                [-0.1, 0.1]), total=2):
            y_values = {}
            errors = {}
            kappas = {}
            for i, shape in enumerate(shapes):
                g = [grid for grid in grids if grid.shapes == [shape]][0].grid[key][0]
                kappa = g[1]
                cal = Calibration(prob_rnd=g[0],
                                  kappa=kappa,
                                  grav_nonuniform=eval(key.split('_')[0]),
                                  force_corner=eval(key.split('_')[1]),
                                  rnd_corner=eval(key.split('_')[2]),
                                  shape=shape,
                                  elastic=g[3],
                                  forceTotal=g[4])
                hit_stats = HIT_statistics(cal.get_df(),
                                           results_folder=cal.folder(),
                                           solver_string='gillespie_HIT',
                                           descriptor=cal.descriptor)
                sorted_lengths, y_values_solved, y_values_giveup, error_bar_solved, error_bar_giveup = \
                    hit_stats.get_CDF_per_attempt('L', shape, maxx=maxx['pL'][shape], string='pL')
                    # hit_stats.get_CDF_per_attempt('L', shape, maxx=min_times * maxx['pL_minimal'][shape], string='pL')
                y_values[shape] = y_values_solved[-1]
                errors[shape] = error_bar_solved[-1]
                kappas[shape] = kappa
            for i, shape in enumerate(shapes):
                ax_inelastic.errorbar(i + shift,
                                      y_values[shape], yerr=errors[shape],
                                      color=color, marker='o', linestyle='-', markersize=10/kappas[shape])
            ax_inelastic.plot([ii + shift for ii in range(len(shapes))],
                              y_values.values(), label=label, color=color, linestyle='-', marker='')
        for grids, label, color, shift in tqdm(zip(
                [grids_elastic_best, grids_elastic_same],
                ['best performing\nsimulation', 'fixed-param.\nsimulation'],
                ['red', 'blue'],
                [-0.1, 0.1]), total=2):
            y_values = {}
            errors = {}
            kappas = {}
            for i, shape in enumerate(shapes_small):
                g = [grid for grid in grids if grid.shapes == [shape]][0].grid[key][0]
                kappa = g[1]
                cal = Calibration(prob_rnd=g[0],
                                  kappa=kappa,
                                  grav_nonuniform=eval(key.split('_')[0]),
                                  force_corner=eval(key.split('_')[1]),
                                  rnd_corner=eval(key.split('_')[2]),
                                  shape=shape,
                                  elastic=g[3],
                                  forceTotal=g[4])
                hit_stats = HIT_statistics(cal.get_df(),
                                           results_folder=cal.folder(),
                                           solver_string='gillespie_HIT',
                                           descriptor=cal.descriptor)
                sorted_lengths, y_values_solved, y_values_giveup, error_bar_solved, error_bar_giveup = \
                    hit_stats.get_CDF_per_attempt('L', shape, maxx=maxx['pL'][shape], string='pL')
                    # hit_stats.get_CDF_per_attempt('L', shape, maxx=min_times * maxx['pL_minimal'][shape], string='pL')

                y_values[shape] = y_values_solved[-1]
                errors[shape] = error_bar_solved[-1]
                kappas[shape] = kappa
            for i, shape in enumerate(shapes_small):
                ax_elastic.errorbar(i + shift,
                                    y_values[shape], yerr=errors[shape],
                                    color=color, marker='o', linestyle='-', markersize=20/kappas[shape])
            ax_elastic.plot([ii + shift for ii in range(len(shapes_small))], y_values.values(),
                              label=label, color=color, linestyle='-', marker='')


        # ax_inelastic.set_title(sim_names[key])
        ax_inelastic.set_ylim(-10, 110)
        ax_elastic.set_ylim(-10, 110)
        ax_inelastic.axhline(0, color='black', linewidth=0.5)
        ax_elastic.axhline(0, color='black', linewidth=0.5)
        ax_inelastic.axhline(100, color='black', linewidth=0.5)
        ax_elastic.axhline(100, color='black', linewidth=   0.5)

        ticklabels = {'I': 'I', 'T': 'T', 'H': 'H', 'SPT': 'H2', 'LongT': 'T2'}

        ax_inelastic.set_xticks(range(len(shapes)))
        ax_inelastic.set_xticklabels([ticklabels[s] for s in shapes])
        ax_elastic.set_xticks(range(len(shapes_small)))
        ax_elastic.set_xticklabels([ticklabels[s] for s in shapes_small])

    # for axs_prob_inelastic add subplot labels ('e', 'f', 'g', 'h') in for loop
    for i, ax in enumerate(axs_prob_inelastic):
        ax.text(0, 1.1, chr(101 + i), transform=ax.transAxes, fontsize=16, va='top', ha='right', fontweight='bold')
    for i, ax in enumerate(axs_prob_elastic):
        ax.text(0, 1.1, chr(105 + i), transform=ax.transAxes, fontsize=16, va='top', ha='right', fontweight='bold')


    axs_prob_inelastic[0].set_ylabel('solution probability [%]')
    axs_prob_elastic[0].set_ylabel('solution probability [%]')
    axs_prob_inelastic[-1].legend(loc='upper left', bbox_to_anchor=(1.05, 0.8))
    axs_prob_elastic[-1].legend(loc='upper left', bbox_to_anchor=(1.05, 0.8))

    # write above the legend 'inelastic'
    axs_prob_inelastic[-1].text(1.1, 0.1, 'simulations with\ninelastic collisions,\nhigh persistence' , va='center', ha='left',
                                fontweight='bold', fontsize=12,
                                rotation=0, transform=axs_prob_inelastic[-1].transAxes)
    axs_prob_elastic[-1].text(1.1, 0.1, 'simulations with\nelastic collisions,\nlow persistence', va='center', ha='left',
                              fontweight='bold', fontsize=12,
                              rotation=0, transform=axs_prob_elastic[-1].transAxes)
    plt.subplots_adjust(hspace=0.2, wspace=0.2)

    image_path = os.path.join(mini_SaverDirectories['gillespie'], 'types_sim.png')
    image = plt.imread(image_path)
    image_box = OffsetImage(image, zoom=0.17)  # Adjust zoom to fit your plot
    annotation_box = AnnotationBbox(image_box, (2.25, 1.7), frameon=False, xycoords='axes fraction')

    # # Add the image in place of the legend
    axs_prob_inelastic[0].add_artist(annotation_box)

    # add fig = os.path.join(mini_SaverDirectories['gillespie'], f'types_sim.png') to top of plot
    # plt.tight_layout()
    plt.tight_layout()

    plt.savefig(os.path.join(mini_SaverDirectories['gillespie'], f'Fig3_with_sum.svg'), bbox_inches='tight')
    plt.savefig(os.path.join(mini_SaverDirectories['gillespie'], f'Fig3_with_sum.pdf'), bbox_inches='tight')



if __name__ == '__main__':
    # save_data_for_online()
    play_sim()
    
    # save_simulation_video()

    # x = get('L_SPT_9_kappa_3_prob_rnd_0.2_05-47-46')
    # DEBUG = 1

    # run_simulations(n=15)
    # # wall_following()
    # save_best_grids()
    # heatmaps()
    # performance_plots()
    # new_performance_plots()

    # keys_smart = ['_'.join(map(str, item)) for item in [(True, True, True)]]
    # for size, elastic in [('M', 1), ('XL', 0)]:
    #     parameters = [(p, k, None, elastic) for (p, k, e) in product(prob_rnds, kappas, [elastic])]
    #     grid_sim_smart = GridIterator({k: parameters for k in keys_smart}, shapes)
    #     grid_exp = GridIterator_exp(size)
    #     comp = Compare(grid_sim_smart, grid_exp)
    #     comp.save_grid_distances('pL', elastic=elastic)
    #     comp.find_smallest_distance_for_each_shape_and_size('pL', elastic=elastic)

