import numpy as np
from Box2D import b2BodyDef, b2_staticBody, b2World, b2_dynamicBody, b2FixtureDef, b2CircleShape, b2Vec2
from Setup.MazeFunctions import BoxIt
from scipy.spatial import cKDTree
from pandas import read_excel
from Directories import maze_dimension_directory, home
from PhysicsEngine.drawables import Polygon, Point, Circle, colors
from copy import copy
from os import path
from trajectory_inheritance.exp_types import is_exp_valid, centerOfMass_shift
import json
from typing import Union
import pandas as pd
from tabulate import tabulate

ant_dimensions = ['ant', 'ps_simulation', 'sim', 'gillespie', 'pheidole']  # also in Maze.py

# TODO: x = get(myDataFrame.loc[429].filename).play() displays a maze, that does not make any sense!

import numpy as np


def snap_angle_to_valid(theta):
    """Snap an angle to the nearest multiple of 45 degrees."""
    return np.round(theta / 45) * 45


def adjust_points(x, y):
    """Adjust points so that angles between vertices are only 45° or 90°."""
    new_x, new_y = [x[0]], [y[0]]

    for i in range(1, len(x)):
        dx = x[i] - x[i - 1]
        dy = y[i] - y[i - 1]

        # Compute the angle in degrees
        theta = np.degrees(np.arctan2(dy, dx))

        # Snap the angle to the nearest 45°
        snapped_theta = snap_angle_to_valid(theta)

        # Compute the new point based on the snapped angle
        distance = np.sqrt(dx ** 2 + dy ** 2)
        new_dx = distance * np.cos(np.radians(snapped_theta))
        new_dy = distance * np.sin(np.radians(snapped_theta))

        # Update the new point
        new_x.append(new_x[-1] + new_dx)
        new_y.append(new_y[-1] + new_dy)

    return np.array(new_x), np.array(new_y)


ASSYMETRIC_H_SHIFT = 1.22 * 2
# SPT_RATIO = 2.44 / 4.82  # ratio between shorter and longer side on the Special T
# My PS are still for the original value below!!
# centerOfMass_shift = - 0.10880829015544041  # shift of the center of mass away from the center of the load.

# size_per_shape = {'ant': {'H': ['XS', 'S', 'M', 'L', 'SL', 'XL'],
#                           'I': ['XS', 'S', 'M', 'L', 'SL', 'XL'],
#                           'T': ['XS', 'S', 'M', 'L', 'SL', 'XL'],
#                           'SPT': ['S', 'M', 'L', 'XL'],
#                           'RASH': ['S', 'M', 'L', 'XL'],
#                           'LASH': ['S', 'M', 'L', 'XL'],
#                           },
#                   'human': {'SPT': ['S', 'M', 'L']},
#                   'humanhand': {'SPT': ['']}
#                   }

with open(path.join(home, 'Setup', 'ResizeFactors.json'), "r") as read_content:
    ResizeFactors = json.load(read_content)
ResizeFactors['ant'][''] = 1
ResizeFactors['gillespie'][''] = 1


# ResizeFactors = {'ant': {'XL': 1, 'SL': 0.75, 'L': 0.5, 'M': 0.25, 'S': 0.125, 'XS': 0.125 / 2},
#                  'pheidole': {'XL': 1, 'SL': 0.75, 'L': 0.5, 'M': 0.25, 'S': 0.125, 'XS': 0.125 / 2},
#                  'human': {'Small Near': 1, 'Small Far': 1, 'Medium': 1, 'Large': 1},
#                  'humanhand': {'': 1}}
# ResizeFactors['ps_simulation'] = dict(ResizeFactors['ant'], **ResizeFactors['human'], **ResizeFactors['humanhand'])
# ResizeFactors['gillespie'] = dict(ResizeFactors['ant'], **ResizeFactors['human'], **ResizeFactors['humanhand'])


def start(x, initial_cond: str):
    if initial_cond not in ['back', 'front']:
        raise ValueError('You initial_cond is not valid.')
    maze = Maze(x)
    if x.shape == 'SPT':
        if initial_cond == 'back':
            # return [(maze.slits[0] - maze.slits[-1]) / 2 + maze.slits[-1] - 0.5, maze.arena_height / 2, 0]
            return [maze.slits[0] * 0.5, maze.arena_height / 2, 0]
        elif initial_cond == 'front':
            return [maze.slits[0] + (maze.slits[1] - maze.slits[0]) * 0.4, maze.arena_height / 2, 0]
    elif x.shape in ['H', 'I', 'T', 'RASH', 'LASH']:
        return [maze.slits[0] - 5, maze.arena_height / 2, np.pi - 0.1]


def end(x):
    """
    :param x: Trajectory object
    :return: list with coordinates of end of SPT
    """
    maze = Maze(x)
    return [maze.slits[-1] * 1.26, maze.arena_height / 2, 0]


class Maze_parent(b2World):
    def __init__(self, position=None, angle=0, point_particle=False, bb: bool = False, free=False, reduced=False):
        super().__init__(gravity=(0, 0), doSleep=True)

        if not hasattr(self, 'size'):
            self.size = 'XL'
        if not hasattr(self, 'shape'):
            self.shape = 'SPT'
        if not hasattr(self, 'solver'):
            self.solver = 'ant'
        if not hasattr(self, 'arena_height'):
            self.arena_height = 10
        if not hasattr(self, 'arena_length'):
            self.arena_length = 'XL'
        if not hasattr(self, 'excel_file_load'):
            if self.shape == 'SPT':
                self.excel_file_load = 'LoadDimensions_new2021_SPT_ant.xlsx'
            else:
                self.excel_file_load = 'LoadDimensions_ant.xlsx'

        self.maze = self.create_Maze(reduced=reduced, free=free)
        self.free = free
        self.create_Load(position=position, angle=angle, point_particle=point_particle, bb=bb, reduced=reduced)

    def create_Maze(self, reduced=False):
        pass

    def set_configuration(self, position, angle):
        self.bodies[-1].position.x, self.bodies[-1].position.y, self.bodies[-1].angle = position[0], position[1], angle

    def elongate(self, elongation):
        self.arena_length = 4 * self.arena_length

    def create_Load(self, position=None, angle=0, point_particle=False, bb: bool = False, reduced=False):

        if position is None:
            position = [0, 0]
        self.CreateBody(b2BodyDef(position=(float(position[0]), float(position[1])),
                                  angle=float(angle),
                                  type=b2_dynamicBody,
                                  fixedRotation=False,
                                  userData='load',
                                 ),
                        restitution=0,
                        friction=0,
                        )

        self.addLoadFixtures(point_particle=point_particle, bb=bb, reduced=reduced)

    def addLoadFixtures(self, point_particle=False, bb: bool = False, reduced=False):
        if point_particle:
            return

        my_load = self.bodies[-1]
        if self.shape == 'circle':
            from trajectory_inheritance.gillespie import radius
            my_load.CreateFixture(b2FixtureDef(shape=b2CircleShape(pos=(0, 0), radius=radius)),
                                  density=1, friction=0, restitution=0,
                                  )

        if self.shape == 'H':
            [shape_height, shape_width, shape_thickness] = self.getLoadDim()
            my_load.CreatePolygonFixture(vertices=[
                (shape_width / 2, shape_thickness / 2),
                (shape_width / 2, -shape_thickness / 2),
                (-shape_width / 2, -shape_thickness / 2),
                (-shape_width / 2, shape_thickness / 2)],
                density=1, friction=0, restitution=0,
            )

            my_load.CreatePolygonFixture(vertices=[
                (shape_width / 2, -shape_height / 2),
                (shape_width / 2, shape_height / 2),
                (shape_width / 2 - shape_thickness, shape_height / 2),
                (shape_width / 2 - shape_thickness, -shape_height / 2)],
                density=1, friction=0, restitution=0,
            )

            my_load.CreatePolygonFixture(vertices=[
                (-shape_width / 2, -shape_height / 2),
                (-shape_width / 2, shape_height / 2),
                (-shape_width / 2 + shape_thickness, shape_height / 2),
                (-shape_width / 2 + shape_thickness, -shape_height / 2)],
                density=1, friction=0, restitution=0,
            )

        if self.shape in ['LongI', 'I']:
            [shape_height, _, shape_thickness] = self.getLoadDim()
            my_load.CreatePolygonFixture(vertices=[
                (shape_height / 2, -shape_thickness / 2),
                (shape_height / 2, shape_thickness / 2),
                (-shape_height / 2, shape_thickness / 2),
                (-shape_height / 2, -shape_thickness / 2)],
                density=1, friction=0, restitution=0,
            )

        if self.shape in ['T', 'LongT']:
            [shape_height, shape_width, shape_thickness] = self.getLoadDim()
            resize_factor = ResizeFactors[self.solver][self.size]
            if self.shape == 'LongT':
                h = 0.5
            else:
                h = 1.35 * resize_factor  # distance of the centroid away from the center of the lower force_vector of

            #  Top horizontal T force_vector
            my_load.CreatePolygonFixture(vertices=[
                ((-shape_height + shape_thickness) / 2 + h, -shape_width / 2),
                ((-shape_height - shape_thickness) / 2 + h, -shape_width / 2),
                ((-shape_height - shape_thickness) / 2 + h, shape_width / 2),
                ((-shape_height + shape_thickness) / 2 + h, shape_width / 2)],
                density=1, friction=0, restitution=0,
            )

            #  Bottom vertical T force_vector
            my_load.CreatePolygonFixture(vertices=[
                ((-shape_height + shape_thickness) / 2 + h, -shape_thickness / 2),
                ((shape_height - shape_thickness) / 2 + h, -shape_thickness / 2),
                ((shape_height - shape_thickness) / 2 + h, shape_thickness / 2),
                ((-shape_height + shape_thickness) / 2 + h, shape_thickness / 2)], density=1, friction=0, restitution=0)

        if self.shape == 'SPT':  # This is the Special T
            [shape_height, shape_width, shape_thickness, short_edge] = self.getLoadDim()
            h = centerOfMass_shift * shape_width  # distance of the centroid away from the center of the long middle
            if not reduced:
                if bb:
                    my_load.CreatePolygonFixture(vertices=[
                        (shape_width / 2 - h, shape_height / 2),
                        (shape_width / 2 - h, -shape_height / 2),
                        (-shape_width / 2 - h, -shape_height / 2),
                        (-shape_width / 2 - h, shape_height / 2)],
                        density=1, friction=0, restitution=0,
                    )
                    return

                # This is the short side
                my_load.CreatePolygonFixture(vertices=[
                    (shape_width / 2 - h, -short_edge / 2),
                    # This addition is because the special T looks like an H where one vertical side is shorter by a factor
                    # SPT_ratio
                    (shape_width / 2 - h, short_edge / 2),
                    (shape_width / 2 - shape_thickness - h, short_edge / 2),
                    (shape_width / 2 - shape_thickness - h, -short_edge / 2)],
                    density=1, friction=0, restitution=0,
                )

            # This is the connecting middle piece
            my_load.CreatePolygonFixture(vertices=[
                (shape_width / 2 - h, shape_thickness / 2),
                (shape_width / 2 - h, -shape_thickness / 2),
                (-shape_width / 2 - h, -shape_thickness / 2),
                (-shape_width / 2 - h, shape_thickness / 2)],
                density=1, friction=0, restitution=0,
            )

            # This is the long side
            my_load.CreatePolygonFixture(vertices=[
                (-shape_width / 2 - h, -shape_height / 2),
                (-shape_width / 2 - h, shape_height / 2),
                (-shape_width / 2 + shape_thickness - h, shape_height / 2),
                (-shape_width / 2 + shape_thickness - h, -shape_height / 2)],
                density=1, friction=0, restitution=0,
            )

        if self.shape == 'RASH':  # This is the ASymmetrical H
            [shape_height, shape_width, shape_thickness] = self.getLoadDim()
            assymetric_h_shift = ASSYMETRIC_H_SHIFT * ResizeFactors[self.solver][self.size]
            # I multiply all these values with 2, because I got them in L, but want to state
            # them in XL.
            my_load.CreatePolygonFixture(vertices=[
                (shape_width / 2, shape_thickness / 2,),
                (shape_width / 2, -shape_thickness / 2,),
                (-shape_width / 2, -shape_thickness / 2,),
                (-shape_width / 2, shape_thickness / 2,)],
                density=1, friction=0, restitution=0,
            )

            my_load.CreatePolygonFixture(vertices=[
                (shape_width / 2, -shape_height / 2 + assymetric_h_shift,),
                # This addition is because the special T looks like an H where one vertical side is shorter by a factor
                # SPT_ratio
                (shape_width / 2, shape_height / 2,),
                (shape_width / 2 - shape_thickness, shape_height / 2,),
                (shape_width / 2 - shape_thickness, -shape_height / 2 + assymetric_h_shift,)],
                density=1, friction=0, restitution=0,
            )

            my_load.CreatePolygonFixture(vertices=[
                (-shape_width / 2, -shape_height / 2,),
                (-shape_width / 2, shape_height / 2 - assymetric_h_shift,),
                (-shape_width / 2 + shape_thickness, shape_height / 2 - assymetric_h_shift,),
                (-shape_width / 2 + shape_thickness, -shape_height / 2,)],
                density=1, friction=0, restitution=0,
            )

        if self.shape == 'LASH':  # This is the ASymmetrical H
            [shape_height, shape_width, shape_thickness] = self.getLoadDim()
            assymetric_h_shift = ASSYMETRIC_H_SHIFT * ResizeFactors[self.solver][self.size]
            # I multiply all these values with 2, because I got them in L, but want to state
            # them in XL.
            my_load.CreatePolygonFixture(vertices=[
                (shape_width / 2, shape_thickness / 2,),
                (shape_width / 2, -shape_thickness / 2,),
                (-shape_width / 2, -shape_thickness / 2,),
                (-shape_width / 2, shape_thickness / 2,)],
                density=1, friction=0, restitution=0,
            )

            my_load.CreatePolygonFixture(vertices=[
                (shape_width / 2, -shape_height / 2,),
                # This addition is because the special T looks like an H where one vertical side is shorter by a factor
                # SPT_ratio
                (shape_width / 2, shape_height / 2 - assymetric_h_shift,),
                (shape_width / 2 - shape_thickness, shape_height / 2 - assymetric_h_shift,),
                (shape_width / 2 - shape_thickness, -shape_height / 2,)],
                density=1, friction=0, restitution=0,
            )

            my_load.CreatePolygonFixture(vertices=[
                (-shape_width / 2, -shape_height / 2 + assymetric_h_shift,),
                (-shape_width / 2, shape_height / 2,),
                (-shape_width / 2 + shape_thickness, shape_height / 2,),
                (-shape_width / 2 + shape_thickness, -shape_height / 2 + assymetric_h_shift,)],
                density=1, friction=0, restitution=0,
            )
        return my_load

    def getLoadDim(self):
        df = read_excel(path.join(maze_dimension_directory, self.excel_file_load), engine='openpyxl')

        if self.shape != 'SPT' and self.solver in ant_dimensions:
            d = df.loc[df['Name'] == self.shape]
            shape_sizes = [d['height'].values[0], d['width'].values[0], d['thickness'].values[0]]
            resize_factor = ResizeFactors[self.solver][self.size]
            if self.shape == 'LongT':
                resize_factor = 1
            dimensions = [i * resize_factor for i in shape_sizes]

            if (resize_factor == 1) and self.shape[1:] == 'ASH':  # for XL ASH
                dimensions = [le * resize_factor for le in [8.14, 5.6, 1.2]]
            elif (resize_factor == 0.75) and self.shape[1:] == 'ASH':  # for XL ASH
                dimensions = [le * resize_factor for le in [9, 6.2, 1.2]]
            return dimensions

        # if self.excel_file_load in ['LoadDimensions_ant.xlsx']:
        #     d = df.loc[df['Name'] == self.size + '_' + self.shape]

        elif self.excel_file_load in ['LoadDimensions_ant_L_I_425.xlsx', 'LoadDimensions_new2021_SPT_ant.xlsx',
                                      'LoadDimensions_new2021_SPT_ant_perfect_scaling.xlsx',
                                      'LoadDimensions_new2021_SPT_ant_Amir.xlsx']:
            d = df.loc[df['Name'] == self.size + '_' + self.shape]

        elif self.excel_file_load in ['LoadDimensions_human.xlsx']:
            d = df.loc[df['Name'] == self.size[0]]

        elif self.excel_file_load in ['LoadDimensions_humanhand.xlsx']:
            d = df.loc[0]
            return [d['long edge'], d['length'], d['width'], d['short edge']]

        else:
            raise ValueError('Gave dimensions for ' + self.excel_file_load + ' but not matching ' +
                             ' '.join([self.solver, self.shape, self.size]))

        dimensions = [d['long edge'].values[0], d['length'].values[0], d['width'].values[0],
                      d['short edge'].values[0]]
        return dimensions

    def force_attachment_positions_in_trajectory(self, x, reference_frame='maze'):
        """
        force attachment in world coordinates
        """
        initial_pos, initial_angle = copy(self.bodies[-1].position), copy(self.bodies[-1].angle)
        if reference_frame == 'maze':
            force_attachment_positions_in_trajectory = []
            for i in range(len(x.frames)):
                self.set_configuration(x.position[i], x.angle[i])
                force_attachment_positions_in_trajectory.append(self.force_attachment_positions())
            self.set_configuration(initial_pos, initial_angle)
            return np.array(force_attachment_positions_in_trajectory)
        elif reference_frame == 'load':
            self.set_configuration([0, 0], 0)
            force_attachment = np.stack([self.force_attachment_positions() for _ in range(len(x.frames))])
            self.set_configuration(initial_pos, initial_angle)
            return np.array(force_attachment)
        else:
            raise ValueError('Unknown reference frame!')

    def force_attachment_positions(self):
        from trajectory_inheritance.humans import participant_number
        if self.solver == 'human' and self.size == 'Medium' and self.shape == 'SPT':
            # Aviram went counter clockwise in his analysis. I fix this using Medium_id_correction_dict
            [shape_height, shape_width, shape_thickness, _] = self.getLoadDim()
            x29, x38, x47 = (shape_width - 2 * shape_thickness) / 4, 0, -(shape_width - 2 * shape_thickness) / 4

            # (0, 0) is the middle of the shape
            positions = [[shape_width / 2, 0],
                         [x29, shape_thickness / 2],
                         [x38, shape_thickness / 2],
                         [x47, shape_thickness / 2],
                         [-shape_width / 2, shape_height / 4],
                         [-shape_width / 2, -shape_height / 4],
                         [x47, -shape_thickness / 2],
                         [x38, -shape_thickness / 2],
                         [x29, -shape_thickness / 2]]
            h = centerOfMass_shift * shape_width

        elif self.solver == 'human' and self.size == 'Large' and self.shape == 'SPT':
            [shape_height, shape_width, shape_thickness, short_edge] = self.getLoadDim()

            xMNOP = -shape_width / 2
            xLQ = xMNOP + shape_thickness / 2
            xAB = (-1) * xMNOP
            xCZ = (-1) * xLQ
            xKR = xMNOP + shape_thickness
            xJS, xIT, xHU, xGV, xFW, xEX, xDY = [xKR + (shape_width - 2 * shape_thickness) / 8 * i for i in range(1, 8)]

            yA_B = short_edge / 6
            yC_Z = short_edge / 2
            yDEFGHIJ_STUVWXY = shape_thickness / 2
            yK_R = shape_height / 10 * 3  # TODO: Tabea, you changed this
            yL_Q = shape_height / 2
            yM_P = shape_height / 10 * 3
            yN_O = shape_height / 10

            # indices_to_coords in comment describe the index shown in Aviram's tracking movie
            positions = [[xAB, -yA_B],  # 1, A
                         [xAB, yA_B],  # 2, B
                         [xCZ, yC_Z],  # 3, C
                         [xDY, yDEFGHIJ_STUVWXY],  # 4, D
                         [xEX, yDEFGHIJ_STUVWXY],  # 5, E
                         [xFW, yDEFGHIJ_STUVWXY],  # 6, F
                         [xGV, yDEFGHIJ_STUVWXY],  # 7, G
                         [xHU, yDEFGHIJ_STUVWXY],  # 8, H
                         [xIT, yDEFGHIJ_STUVWXY],  # 9, I
                         [xJS, yDEFGHIJ_STUVWXY],  # 10, J
                         [xKR, yK_R],  # 11, K
                         [xLQ, yL_Q],  # 12, L
                         [xMNOP, yM_P],  # 13, M
                         [xMNOP, yN_O],  # 14, N
                         [xMNOP, -yN_O],  # 15, O
                         [xMNOP, -yM_P],  # 16, P
                         [xLQ, -yL_Q],  # 17, Q
                         [xKR, -yK_R],  # 18, R
                         [xJS, -yDEFGHIJ_STUVWXY],  # 19, S
                         [xIT, -yDEFGHIJ_STUVWXY],  # 20, T
                         [xHU, -yDEFGHIJ_STUVWXY],  # 21, U
                         [xGV, -yDEFGHIJ_STUVWXY],  # 22, V
                         [xFW, -yDEFGHIJ_STUVWXY],  # 23, W
                         [xEX, -yDEFGHIJ_STUVWXY],  # 24, X
                         [xDY, -yDEFGHIJ_STUVWXY],  # 25, Y
                         [xCZ, -yC_Z],  # 26, Z
                         ]
            h = centerOfMass_shift * shape_width

        else:
            positions = [[0, 0] for i in range(participant_number[self.size])]
            h = 0

        # centerOfMass_shift the shape...
        positions = [[r[0] - h, r[1]] for r in positions]  # r vectors in the load frame
        return np.array(
            [np.array(self.bodies[-1].GetWorldPoint(b2Vec2(r))) for r in positions])  # r vectors in the lab frame

    def draw(self, display=None, points=[], color=None):
        if display is None:
            from PhysicsEngine.Display import Display
            d = Display('', 1, self)
        else:
            d = display
        for body in self.bodies:
            for fixture in body.fixtures:
                if str(type(fixture.shape)) == "<class 'Box2D.Box2D.b2PolygonShape'>":
                    vertices = [(body.transform * v) for v in fixture.shape.vertices]
                    if len(vertices) > 0:
                        Polygon(vertices, color=colors[body.userData]).draw(d)

                elif str(type(fixture.shape)) == "<class 'Box2D.Box2D.b2CircleShape'>":
                    position = body.position + fixture.shape.pos
                    Circle(position, fixture.shape.radius, color=colors[body.userData]).draw(d)

            if body.userData == 'load':
                Point(np.array(body.position), color=(251, 0, 0)).draw(d)

        for point in points:

            Point(np.array(point), color=color).draw(d)

        if display is None:
            d.display()

    def average_radius(self):
        r = ResizeFactors[self.solver][self.size]
        radii = {'H': 2.9939 * r,
                 'I': 2.3292 * r,
                 'T': 2.9547 * r,
                 'SPT': 0.76791 * self.getLoadDim()[1],
                 'RASH': 2 * 1.6671 * r,
                 'LASH': 2 * 1.6671 * r,
                 'LongI': 5 * r,
                 'LongT': 2.26
                 }
        # if self.shape == 'LongI':
        #     print('I dont really know LongI radius')
        return radii[self.shape]

    def circumference(self):
        if self.shape == 'SPT':
            shape_height, shape_width, shape_thickness, shape_height_short_edge = self.getLoadDim()
        else:
            shape_height, shape_width, shape_thickness = self.getLoadDim()
            shape_height_short_edge = np.NaN

        shift = ASSYMETRIC_H_SHIFT * ResizeFactors[self.solver][self.size]

        cir = {'H': 4 * shape_height - 2 * shape_thickness + 2 * shape_width,
               'I': 2 * shape_height + 2 * shape_width,
               'LongI': 2 * shape_height + 2 * shape_width,
               'T': 2 * shape_height + 2 * shape_width,
               'LongT': 2 * shape_height + 2 * shape_width,
               'SPT': 2 * shape_height_short_edge + 2 * shape_height - 2 * shape_thickness + 2 * shape_width,
               'RASH': 2 * shape_width + 4 * shape_height - 4 * shift - 2 * shape_thickness,
               'LASH': 2 * shape_width + 4 * shape_height - 4 * shift - 2 * shape_thickness
               }

        if self.shape.endswith('ASH'):
            raise ValueError('I do not know circumference of ASH!!!')

        return cir[self.shape]


class Maze(Maze_parent):
    def __init__(self, *args, size='XL', shape='SPT', solver='ant', position=None, angle=0, point_particle=False,
                 geometry: tuple = None, i=0, bb: bool = False, reduced=False, free=False, elongation_factor=1):
        self.arena_length = float()
        self.arena_height = float()
        self.exit_size = float()
        self.wallthick = float()
        self.slits = list()
        self.slitpoints = np.array([])
        self.slitTree = list()

        if len(args) > 0 and type(args[0]).__name__ in ['Trajectory_human', 'Trajectory_ps_simulation',
                                                        'Trajectory_ant', 'Trajectory_gillespie', 'Trajectory',
                                                        'Trajectory_part', 'Trajectory_humanhand']:
            x = args[0]
            if geometry is None:
                self.excel_file_maze, self.excel_file_load = x.geometry()
            else:
                self.excel_file_maze, self.excel_file_load = geometry
            self.shape = x.shape
            self.size = x.size
            self.solver = x.solver
            position = x.position[i] if position is None else position
            angle = x.angle[i] if angle is None else angle
        else:
            if shape in ['H', 'I', 'LongI', 'T']:
                self.excel_file_maze, self.excel_file_load = \
                    'MazeDimensions_ant.xlsx', 'LoadDimensions_ant.xlsx'
            elif shape == 'SPT':
                self.excel_file_maze, self.excel_file_load = \
                    ('MazeDimensions_new2021_SPT_ant_Amir.xlsx',
                     'LoadDimensions_new2021_SPT_ant_Amir.xlsx')
            elif shape == 'LongT':
                self.excel_file_maze, self.excel_file_load = \
                    ('MazeDimensions_LongT.xlsx',
                     'LoadDimensions_LongT.xlsx')
            else:
                raise ValueError('I do not know the maze dimensions for ' + shape)
            self.shape = shape
            self.size = size
            self.solver = solver

        # is_exp_valid(self.shape, self.solver, self.size)
        self.getMazeDim(elongation_factor=elongation_factor)
        super().__init__(position=position, angle=angle, point_particle=point_particle, bb=bb, reduced=reduced)

        if not free:
            self.CreateSlitObject(reduced=reduced)

    def exit(self):
        if not self.shape == 'LongT':
            return [self.slits[-1], self.arena_height/2]
        elif self.shape == 'LongT':
            num = 21, 22, 6, 5 # this is specific to the order of nodes_x and nodes_y
            return [np.mean([self.nodes_x[n] for n in num]), np.mean([self.nodes_y[n] for n in num])]
        elif self.shape == 'SPT':
            return [self.slits[-1], self.arena_height / 2]

    def get_load_corners(self):
        if self.shape in ['H', 'I']:
            [shape_height, shape_width, shape_thickness] = self.getLoadDim()
            return np.array([[-shape_width / 2, -shape_height / 2],
                             [-shape_width / 2, shape_height / 2],
                             [shape_width / 2, shape_height / 2],
                             [shape_width / 2, -shape_height / 2]])
        if self.shape in ['T', 'LongT']:
            [shape_height, shape_width, shape_thickness] = self.getLoadDim()
            return np.array([[-shape_thickness / 2, -shape_height / 2],
                             [-shape_width / 2, shape_height / 2],
                             [shape_width / 2, shape_height / 2],
                             [shape_thickness / 2, -shape_height / 2]])

    def corner_passed_exit(self, r: np.array):
        if self.shape in ['H', 'I', 'T']:
            return r[0] > self.slits[-1]
        elif self.shape in ['LongT']:
            return r[0] > 18

    def in_exit_zone(self, r: np.array):
        if self.shape in ['H', 'I', 'T', 'LongI']:
            return np.logical_and(r[0] > self.slits[-1] - self.wallthick/2,
                                  abs(r[1] - self.arena_height/2) < self.exit_size/2 * 1.2)
        elif self.shape in ['LongT', 'SPT']:
            return True

    def corners(self):
        corners = [[0, 0],
                   [0, self.arena_height],
                   [self.slits[-1] + 20, self.arena_height],
                   [self.slits[-1] + 20, 0],
                   ]
        return np.array(corners + list(np.resize(self.slitpoints, (16, 2))))

    def slit_dist(self):
        return self.slits[-1] - self.slits[0]

    def getMazeDim(self, elongation_factor=1):
        df = read_excel(path.join(maze_dimension_directory, self.excel_file_maze), engine='openpyxl')
        if self.excel_file_maze in ['MazeDimensions_ant.xlsx', 'MazeDimensions_ant_L_I_425.xlsx',
                                    'MazeDimensions_new2021_SPT_ant.xlsx',
                                    'MazeDimensions_new2021_SPT_ant_perfect_scaling.xlsx',
                                    'MazeDimensions_new2021_SPT_ant_Amir.xlsx'
                                    ]:  # all measurements in cm
            d = df.loc[df['Name'] == self.size + '_' + self.shape]
            self.arena_length = int(d['arena_length'].values[0] * elongation_factor)
            self.arena_height = d['arena_height'].values[0] * elongation_factor
            self.exit_size = d['exit_size'].values[0]
            self.wallthick = d['wallthick'].values[0]
            if type(d['slits'].values[0]) == str:
                self.slits = [[float(s) for s in d['slits'].values[0].split(', ')][0],
                              [float(s) for s in d['slits'].values[0].split(', ')][1]]
            else:
                self.slits = [d['slits'].values[0]]

        elif self.excel_file_maze in ['MazeDimensions_LongT.xlsx']:
            # d = df.loc[df['Name'] == self.size + '_' + self.shape]
            self.arena_length = df['arena_length'].values[0]
            self.arena_height = df['arena_height'].values[0]

            # I want to rotate self.nodes_x and self.nodes_y by 90 degrees using a rotation matrix
            self.nodes_x = np.array([df['nodes_x'], df['nodes_y']])[0]
            self.nodes_y = np.array([df['nodes_x'], df['nodes_y']])[1]

        elif self.excel_file_maze in ['MazeDimensions_humanhand.xlsx']:  # only SPT
            d = df.loc[df['Name'] == 'humanhand']
            self.arena_length = d['arena_length'].values[0]
            self.arena_height = d['arena_height'].values[0]
            self.exit_size = d['exit_size'].values[0]
            self.wallthick = d['wallthick'].values[0]
            self.slits = [float(s) for s in d['slits'].values[0].split(', ')]

        elif self.excel_file_maze in ['MazeDimensions_human.xlsx']:  # all measurements in meters
            # StartedScripts: measure the slits again...
            # these coordinate values are given inspired from the drawing in \\phys-guru-cs\ants\Tabea\Human
            # Experiments\ExperimentalSetup
            d = df.loc[df['Name'] == self.size]
            A = [float(s) for s in d['A'].values[0].split(',')]
            # B = [float(s) for s in d['B'].values[0].split(',')]
            C = [float(s) for s in d['C'].values[0].split(',')]
            D = [float(s) for s in d['D'].values[0].split(',')]
            E = [float(s) for s in d['E'].values[0].split(',')]

            self.arena_length, self.exit_size = A[0], D[1] - C[1]
            self.wallthick = 0.1
            self.arena_height = 2 * C[1] + self.exit_size
            self.slits = [(E[0] + self.wallthick / 2),
                          (C[0] + self.wallthick / 2)]  # These are the x positions at which the slits are positions

        self.slitpoints = np.empty((len(self.slits) * 2, 4, 2), float)

    def in_what_Chamber(self, r: np.array) -> Union[int, None]:
        """
        Only works for SPT maze
        Check the x coordinate of the object and return the chamber number
        __________________
                  |    |
            0       1    2
                  |    |
        __________________
        :param r: position of the particle
        :return: the index of the chamber in which the particle is
        """
        if self.shape != 'SPT':
            raise ValueError('No Chambers defined for shape ' + self.shape)

        if r[0] < self.slits[0]:
            return 0
        elif r[0] < self.slits[1]:
            return 1
        elif r[0] < self.slits[1] + (self.slits[1]-self.slits[0]):
            return 2
        return None

    def CreateSlitObject(self, reduced=False):
        # # The x and y position describe the point, where the middle (in x direction) of the top edge (y direction)
        # of the lower wall of the slit is...
        if self.shape == 'LongT':
            assert hasattr(self, 'nodes_x') and hasattr(self, 'nodes_y')
            all_nodes = np.array([self.nodes_x, self.nodes_y]).round(3)

            # print this in latex table format, where the first column is an integer,
            # the second column is the x values and the third column the y values,

            # for i, (x, y) in enumerate(zip(all_nodes[0], all_nodes[1])):
            #     print(f'{i} & {x} & {y} \\\\')



            # test = [[17.6, 0.0], [17.6, 6.275], [17.803, 6.275], [17.803, 0.0]]
            # self.maze.CreatePolygonFixture(vertices=test)
            sets_of_fixt = np.array([
                (1, 2, 13, 14),
                (11, 12, 10, 3),
                (10, 3, 4, 9),
                (4, 9, 5, 8),
                (5, 8, 6, 7),
                (23, 22, 24, 21),
                (21, 24, 20, 25),
                (25, 20, 19, 26),
                (19, 26, 18, 17),
                (16, 27, 28, 15),
                (28, 15, 14, 1)
            ]) - 1
            for set_of_fixt in sets_of_fixt:
                # makes most sense when looking at
                # C:\Users\tabea\Documents\Weizmann_Research\ExperimentalData\ExpSetup\LongT
                self.maze.CreatePolygonFixture(vertices=[all_nodes.T.tolist()[i] for i in set_of_fixt])

            # first_set = all_nodes.T.tolist()[:15]
            # second_set = all_nodes.T.tolist()[14:]
            #
            # from matplotlib import pyplot as plt
            # plt.close()
            # plt.plot([f[1] for f in all_nodes.T.tolist()], [-f[0] for f in all_nodes.T.tolist()], color='k', marker='x')
            # # write number of the nodes
            # for i, txt in enumerate(range(28)):
            #     plt.annotate(txt, (all_nodes.T.tolist()[i][1], -all_nodes.T.tolist()[i][0]))
            #
            # # write x and y and [cm] on the axes
            # plt.ylabel('x [cm]')
            # plt.ylim([-1, 20])
            # plt.xlabel('y [cm]')
            # # equal axis ratio
            # plt.axis('equal')
            #
            # plt.savefig('LongT.svg')
            # plt.savefig('LongT.png')

            # self.maze.CreatePolygonFixture(vertices=first_set)
            # self.maze.CreatePolygonFixture(vertices=second_set)


        if reduced:
            # self.slits = [self.slits[1]]
            self.slitpoints = np.empty((len(self.slits) * 2, 4, 2), float)
            for i, slit in enumerate(self.slits):
                # this is the lower Slit
                mid_y = self.arena_height / 2
                add = self.wallthick/2

                if i == 0:
                    self.slitpoints[2 * i] = np.array([[slit - add, mid_y - self.exit_size / 2 - add],
                                                       [slit - add, mid_y - self.exit_size / 2 + add],
                                                       [slit + add, mid_y - self.exit_size / 2 + add],
                                                       [slit + add, mid_y - self.exit_size / 2 - add]]
                                                      )
                else:
                    self.slitpoints[2 * i] = np.array([[slit - add, 0],
                                                       [slit - add, mid_y - self.exit_size / 2 + add],
                                                       [slit + add, mid_y - self.exit_size / 2 + add],
                                                       [slit + add, 0]]
                                                      )

                self.maze.CreatePolygonFixture(vertices=self.slitpoints[2 * i].tolist())

                # # # this is the upper Slit
                # self.slitpoints[2 * i + 1] = np.array([[slit - add, mid_y + self.exit_size / 2 - self.wallthick / 2],
                #                                        [slit - add, mid_y + self.exit_size / 2 + self.wallthick / 2],
                #                                        [slit + self.wallthick + add, mid_y + self.exit_size / 2 + add],
                #                                        [slit + self.wallthick + add, mid_y + self.exit_size / 2 - add]]
                #                                       )

                # self.maze.CreatePolygonFixture(vertices=self.slitpoints[2 * i + 1].tolist())

            # I dont want to have the vertical line at the first exit
            self.slitTree = BoxIt(np.array([[0, 0],
                                            [0, self.arena_height],
                                            [self.slits[-1], self.arena_height],
                                            [self.slits[-1], 0]]),
                                  0.1, without='right')

            for slit_points in self.slitpoints:
                self.slitTree = np.vstack((self.slitTree, BoxIt(slit_points, 0.01)))

            self.slitTree = cKDTree(self.slitTree)

        # We need a special case for L_SPT because in the manufacturing the slits were not vertically glued
        elif self.size == 'L' and self.shape == 'SPT' and self.excel_file_maze == 'MazeDimensions_ant_old.xlsx':
            slitLength = 4.1
            # this is the left (inside), bottom Slit
            self.slitpoints[0] = np.array([[self.slits[0], 0],
                                           [self.slits[0], slitLength],
                                           [self.slits[0] + self.wallthick, slitLength],
                                           [self.slits[0] + self.wallthick, 0]]
                                          )
            # this is the left (inside), upper Slit
            self.slitpoints[1] = np.array([[self.slits[0] - 0.05, slitLength + self.exit_size],
                                           [self.slits[0] + 0.1, self.arena_height],
                                           [self.slits[0] + self.wallthick + 0.1, self.arena_height],
                                           [self.slits[0] + self.wallthick - 0.05, slitLength + self.exit_size]]
                                          )

            # this is the right (outside), lower Slit
            self.slitpoints[2] = np.array([[self.slits[1], 0],
                                           [self.slits[1] + 0.1, slitLength],
                                           [self.slits[1] + self.wallthick + 0.1, slitLength],
                                           [self.slits[1] + self.wallthick, 0]]
                                          )
            # this is the right (outside), upper Slit
            self.slitpoints[3] = np.array([[self.slits[1] + 0.2, slitLength + self.exit_size],
                                           [self.slits[1] + 0.2, self.arena_height],
                                           [self.slits[1] + self.wallthick + 0.2, self.arena_height],
                                           [self.slits[1] + self.wallthick + 0.2, slitLength + self.exit_size]]
                                          )
        else:
            self.slitpoints = np.empty((len(self.slits) * 2, 4, 2), float)
            for i, slit in enumerate(self.slits):
                # this is the lower Slit
                self.slitpoints[2 * i] = np.array([[slit, 0],
                                                   [slit, (self.arena_height - self.exit_size) / 2],
                                                   [slit + self.wallthick, (self.arena_height - self.exit_size) / 2],
                                                   [slit + self.wallthick, 0]]
                                                  )

                self.maze.CreatePolygonFixture(vertices=self.slitpoints[2 * i].tolist())

                # this is the upper Slit
                self.slitpoints[2 * i + 1] = np.array([[slit, (self.arena_height + self.exit_size) / 2],
                                                       [slit, self.arena_height],
                                                       [slit + self.wallthick, self.arena_height],
                                                       [slit + self.wallthick,
                                                        (self.arena_height + self.exit_size) / 2]]
                                                      )

                self.maze.CreatePolygonFixture(vertices=self.slitpoints[2 * i + 1].tolist())

            # I dont want to have the vertical line at the first exit
            if len(self.slits) > 0:
                self.slitTree = BoxIt(np.array([[0, 0],
                                                [0, self.arena_height],
                                                [self.slits[-1], self.arena_height],
                                                [self.slits[-1], 0]]),
                                      0.1, without='right')

                for slit_points in self.slitpoints:
                    self.slitTree = np.vstack((self.slitTree, BoxIt(slit_points, 0.01)))

                self.slitTree = cKDTree(self.slitTree)

    # def get_zone(self):
    #     if self.shape == 'SPT':
    #         self.zone = np.array([[0, 0],
    #                               [0, self.arena_height],
    #                               [self.slits[0], self.arena_height],
    #                               [self.slits[0], 0]])
    #     else:
    #         RF = ResizeFactors[self.solver][self.size]
    #         self.zone = np.array(
    #             [[self.slits[0] - self.arena_length * RF / 2, self.arena_height / 2 - self.arena_height * RF / 2],
    #              [self.slits[0] - self.arena_length * RF / 2, self.arena_height / 2 + self.arena_height * RF / 2],
    #              [self.slits[0], self.arena_height / 2 + self.arena_height * RF / 2],
    #              [self.slits[0], self.arena_height / 2 - self.arena_height * RF / 2]])
    #     return

    # def possible_state_transitions(self, From, To):
    #     transitions = dict()
    #
    #     s = self.statenames
    #     if self.shape == 'H':
    #         transitions[s[0]] = [s[0], s[1], s[2]]
    #         transitions[s[1]] = [s[1], s[0], s[2], s[3]]
    #         transitions[s[2]] = [s[2], s[0], s[1], s[4]]
    #         transitions[s[3]] = [s[3], s[1], s[4], s[5]]
    #         transitions[s[4]] = [s[4], s[2], s[3], s[5]]
    #         transitions[s[5]] = [s[5], s[3], s[4]]
    #         return transitions[self.states[-1]].count(To) > 0
    #
    #     if self.shape == 'SPT':
    #         transitions[s[0]] = [s[0], s[1]]
    #         transitions[s[1]] = [s[1], s[0], s[2]]
    #         transitions[s[2]] = [s[2], s[1], s[3]]
    #         transitions[s[3]] = [s[3], s[2], s[4]]
    #         transitions[s[4]] = [s[4], s[3], s[5]]
    #         transitions[s[5]] = [s[5], s[4], s[6]]
    #         transitions[s[6]] = [s[6], s[5]]
    #         return transitions[self.states[From]].count(To) > 0

    def minimal_path_length(self):
        from DataFrame.dataFrame import myDataFrame
        # from trajectory_inheritance.trajectory_ps_simulation import filename_dstar
        p = myDataFrame.loc[myDataFrame['filename'] == filename_dstar(self.size, self.shape, 0, 0)][
            ['path length [length unit]']]
        return p.values[0][0]

    def create_Maze(self, reduced=False, free=False):
        my_maze = self.CreateBody(b2BodyDef(position=(0, 0), angle=0, type=b2_staticBody, userData='maze'))
        if not free:
            my_maze.CreateLoopFixture(
                vertices=[(0, 0),
                          (0, float(self.arena_height)),
                          (float(self.arena_length), float(self.arena_height)),
                          (float(self.arena_length), 0)])
        else:
            my_maze.CreateLoopFixture(
                vertices=[(0, 0),
                          (0, float(self.arena_height)),
                          (float(self.arena_length), float(self.arena_height)),
                          (float(self.arena_length), 0)])

        return my_maze


class Maze_free_space(Maze_parent):
    def __init__(self, *args, size='XL', shape='SPT', solver='ant', position=None, angle=0, point_particle=False,
                 geometry: tuple = None, i=0, bb: bool = False):
        if len(args) > 0 and type(args[0]).__name__ in ['Trajectory_human', 'Trajectory_ps_simulation',
                                                        'Trajectory_ant', 'TrajectoryGillespie', 'Trajectory',
                                                        'Trajectory_part']:
            x = args[0]
            self.arena_height = np.max(x.position[:, 1])
            self.arena_length = np.max(x.position[:, 0])
            self.excel_file_maze, self.excel_file_load = x.geometry()
            self.shape = x.shape
            self.size = x.size
            self.solver = x.solver
            position = x.position[i] if position is None else position
            angle = x.angle[i] if angle is None else angle
        else:
            self.arena_height = 10
            self.arena_length = 10
            self.excel_file_maze, self.excel_file_load = geometry
            self.shape = shape
            self.size = size
            self.solver = solver

        super().__init__(position=position, angle=angle, point_particle=point_particle, bb=bb, free=True)

    def create_Maze(self, reduced=False):
        my_maze = self.CreateBody(b2BodyDef(position=(0, 0), angle=0, type=b2_staticBody, userData='maze'))
        my_maze.CreateLoopFixture(
            vertices=[(0, 0), (0, self.arena_height), (self.arena_length, self.arena_height),
                      (self.arena_length, 0)])
        return my_maze

#
# print({size: Maze(size=size, shape='SPT', solver='human',
#                   geometry=('MazeDimensions_human.xlsx', 'LoadDimensions_human.xlsx')).average_radius()
#        for size in ['Large', 'Medium', 'Small Far']})


def latex_table():
    # Load Excel file into a DataFrame
    excel_file = 'Dimensions_for_paper.xlsx'  # Replace with your actual Excel file path

    # average_radius = {'ant': {'S': 0.921492, 'S (> 1)': 0.921492, 'Single (1)': 0.921492, 'M': 1.842981,
    #                           'L': 3.662930, 'XL': 7.295145},
    #                   'human': {'Small Far': 1.1979396, 'Small Near': 1.1979396, 'Small': 1.1979396,
    #                             'Medium': 2.441953, 'Large': 4.8992658},
    #                   'gillespie': {'S': 0.921492, 'S (> 1)': 0.921492, 'Single (1)': 0.921492, 'M': 1.842981,
    #                                 'L': 3.662930, 'XL': 7.295145}}

    df_original = pd.read_excel(excel_file).T
    # Round all values in the DataFrame
    df = df_original.apply(pd.to_numeric, errors='coerce')
    df = df.round(decimals=2)  # Adjust the number of decimals as needed

    # replace rows solver and group size with df_original
    df.loc['solver'] = df_original.loc['solver']
    df.loc['group size'] = df_original.loc['group size']
    df.loc['unit'] = df_original.loc['unit']

    # Convert DataFrame to LaTeX table format
    latex_table = tabulate(df, tablefmt='latex', )

    # Print or save the LaTeX table
    print(latex_table)

    # If you want to save the LaTeX table to a file, uncomment the following line
    # with open('output_table.tex', 'w') as f:
    #     f.write(latex_table)


if __name__ == '__main__':
    # make table for paper in latex
    maze = Maze(size='', shape='LongT', solver='ant',)

    # latex_table()
    average_radius = {}
    for shape in ['I', 'T', 'H']:
        average_radius[shape] = {}
        for size in ['M', 'L', 'SL', 'XL']:
            maze = Maze(size=size, shape=shape, solver='ant',
                        geometry=('MazeDimensions_ant.xlsx', 'LoadDimensions_ant.xlsx'))
            average_radius[shape][size] = maze.average_radius()
    print(average_radius)



    # # open human maze
    # maze = Maze(size='Large', shape='SPT', solver='human',
    #             geometry=('MazeDimensions_human.xlsx', 'LoadDimensions_human.xlsx'))
    # average_radius = {'ant': {'S': 0.921492, 'M': 1.842981, 'L': 3.662930, 'XL': 7.295145},
    #                   'human': {'Small': 1.1979396, 'Medium': 2.441953, 'Large': 4.8992658}}
    #
    # arena_height = {'ant': {'XL': 19.1, 'L': 9.5, 'M': 4.8, 'S': 2.48, 'S (> 1)': 2.48, 'Single (1)': 2.48,},
    #                 'human': {'Small': 3.3, 'Medium': 6.39, 'Large': 12.57}}
    # slit_dist = {'human': {'Small': 1.06, 'Medium': 2.16, 'Large': 4.24}}