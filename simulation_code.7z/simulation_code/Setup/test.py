from trajectory_inheritance.get import get

x = get('L_H_4140001_1_ants')
x.play()
